import { Department, DetectedIssue, Priority, LocationInfo } from '../types';

export interface AIAnalysisResult {
  complaint_id: string;
  original_complaint: string;
  detected_language: string;
  location: Partial<LocationInfo>;
  issues_detected: DetectedIssue[];
  summary: string;
  aiEngineUsed: string;
  potentialDuplicate?: {
    id: string;
    similarity: number;
    title: string;
  };
}

interface NationalDepartmentRule {
  department: Department;
  aliases: string[];
  defaultAction: string;
  defaultPriority: Priority;
  deadline: string;
  deadlineHours: number;
  englishKeywords: string[];
  hindiKeywords: string[];
  tamilKeywords: string[];
  regionalAndTransliteratedKeywords: string[];
  defaultOfficer: string;
  officerPhone: string;
}

export const NATIONAL_DEPARTMENT_RULES: Record<string, NationalDepartmentRule> = {
  sanitation: {
    department: 'Municipal Corporation / Sanitation',
    aliases: ['Sanitation / Corporation', 'Solid Waste Management', 'Nagar Nigam'],
    defaultAction: 'Desilt blocked stormwater drains, clear garbage accumulation, and conduct bleaching sanitization.',
    defaultPriority: 'High',
    deadline: '48 Hours',
    deadlineHours: 48,
    englishKeywords: ['drainage', 'drain', 'sewage', 'sewer', 'gutter', 'overflow', 'clogged', 'blocked drain', 'stagnant water', 'garbage', 'trash', 'waste', 'dump', 'dustbin', 'cleaning', 'stench', 'smell', 'filth', 'manhole'],
    hindiKeywords: ['नाली', 'सीवर', 'गटर', 'कचरा', 'गंदगी', 'सफाई', 'कूड़ा', 'बदबू', 'नाला', 'सीवरेज', 'गंदा पानी', 'डस्टबिन', 'मैल'],
    tamilKeywords: ['வடிகால்', 'சாக்கடை', 'குப்பை', 'கழிவுநீர்', 'அடைப்பு', 'கழிவு', 'தூய்மை', 'துர்நாற்றம்'],
    regionalAndTransliteratedKeywords: ['kachra', 'gandagi', 'nali', 'gutter', 'sewer jam', 'kura', 'sewage leak', 'sakkadai', 'kuppai', 'manhole', 'stink', 'dustbin overflow', 'chetha', 'mori'],
    defaultOfficer: 'R. K. Sharma (Chief Municipal Health Officer)',
    officerPhone: '+91 98100 45210',
  },
  electricity: {
    department: 'Electricity Department',
    aliases: ['Electricity Board (TANGEDCO)', 'State DISCOM', 'Power Corporation'],
    defaultAction: 'Inspect low-tension distribution line, replace burnt fuses/transformer, and install working LED streetlights.',
    defaultPriority: 'Medium',
    deadline: '7 Days',
    deadlineHours: 168,
    englishKeywords: ['streetlight', 'street light', 'lamp', 'light', 'electricity', 'power', 'power cut', 'current', 'voltage', 'transformer', 'wire', 'cable', 'hanging wire', 'spark', 'blackout', 'load shedding', 'meter'],
    hindiKeywords: ['बिजली', 'करंट', 'लाइट', 'स्ट्रीटलाइट', 'स्ट्रीट लाइट', 'ट्रांसफार्मर', 'तार', 'खंभा', 'पावर कट', 'वोल्टेज', 'अंधेरा', 'मीटर'],
    tamilKeywords: ['தெருவிளக்கு', 'மின்சாரம்', 'மின் கம்பம்', 'மின்வெட்டு', 'மின் கம்பி', 'மின்கசிவு', 'விளக்கு'],
    regionalAndTransliteratedKeywords: ['bijli', 'current cut', 'power cut', 'transformer blast', 'tar toot gaya', 'light kharab', 'theruvilakku', 'kambha', 'voltage fluctuation', 'andhera'],
    defaultOfficer: 'Er. A. K. Verma (Superintending Engineer - Power Distribution)',
    officerPhone: '+91 98112 34980',
  },
  pwd: {
    department: 'Public Works Department (PWD)',
    aliases: ['State PWD', 'Roads & Bridges', 'Highways Department'],
    defaultAction: 'Conduct road patchworks, fill hazardous potholes with hot-mix asphalt, and reconstruct damaged culverts.',
    defaultPriority: 'Medium',
    deadline: '7 Days',
    deadlineHours: 168,
    englishKeywords: ['road', 'pothole', 'potholes', 'damaged road', 'tar road', 'bridge', 'culvert', 'flyover', 'divider', 'crater', 'asphalt', 'footpath', 'speed breaker', 'broken road'],
    hindiKeywords: ['सड़क', 'सडक', 'गड्ढा', 'गड्ढे', 'पुल', 'रास्ता', 'टूटी सड़क', 'फ्लाईओवर', 'डामर', 'फुटपाथ', 'डिवाइडर'],
    tamilKeywords: ['சாலை', 'ரோடு', 'பள்ளம்', 'பாலம்', 'சேதமடைந்த சாலை', 'தார் சாலை'],
    regionalAndTransliteratedKeywords: ['sadak kharab', 'gaddhe', 'pothole', 'toota road', 'rasta', 'pallam', 'pulia', 'footpath toota', 'speed breaker', 'crater'],
    defaultOfficer: 'Er. S. Sengupta (Executive Engineer - PWD Roads)',
    officerPhone: '+91 98301 77241',
  },
  water: {
    department: 'Water Supply Department',
    aliases: ['Water Board (Metro Water)', 'Jal Board', 'PHE Water Works'],
    defaultAction: 'Rectify pipeline pressure, repair distribution pipe burst, and restore clean potable drinking water supply.',
    defaultPriority: 'High',
    deadline: '48 Hours',
    deadlineHours: 48,
    englishKeywords: ['water', 'drinking water', 'tap water', 'water supply', 'pipeline', 'pipe', 'leakage', 'leak', 'no water', 'supply', 'water shortage', 'dirty water', 'muddy water', 'contamination', 'tanker'],
    hindiKeywords: ['पानी', 'जल', 'पाइपलाइन', 'लीकेज', 'सप्लाई', 'गंदा पानी', 'पीने का पानी', 'नल', 'टैंकर', 'पानी नहीं आ रहा', 'जलकल', 'टूटी पाइप'],
    tamilKeywords: ['குடிநீர்', 'தண்ணீர்', 'குழாய்', 'கசிவு', 'தண்ணீர் வரவில்லை', 'குடிநீர் வாரியம்', 'சாக்கடை கலந்த தண்ணீர்'],
    regionalAndTransliteratedKeywords: ['pani nahi aa raha', 'ganda pani', 'water pipe burst', 'pipe leak', 'jal board', 'tap water', 'tanker mafia', 'thanner', 'kudineer'],
    defaultOfficer: 'V. Sundaram (Divisional Engineer - Water Supply)',
    officerPhone: '+91 98401 56210',
  },
  health: {
    department: 'Health Department',
    aliases: ['Health & Family Welfare', 'Public Health Department'],
    defaultAction: 'Conduct anti-rabies vaccination, stray animal capture, vector-borne disease fogging, and clinic medical audit.',
    defaultPriority: 'Medium',
    deadline: '3 Days',
    deadlineHours: 72,
    englishKeywords: ['dog', 'dogs', 'stray dog', 'rabies', 'bites', 'animal', 'mosquito', 'dengue', 'malaria', 'fever', 'clinic', 'phc', 'hospital', 'food safety', 'epidemic', 'doctor'],
    hindiKeywords: ['कुत्ता', 'कुत्ते', 'आवारा कुत्ते', 'मच्छर', 'डेंगू', 'मलेरिया', 'बीमारी', 'अस्पताल', 'दवा', 'क्लिनिक', 'डॉक्टर', 'टीका', 'बुखार'],
    tamilKeywords: ['நாய்', 'தெரு நாய்', 'கொசு', 'டெங்கு', 'காய்ச்சல்', 'மருத்துவமனை', 'சுகாதாரம்'],
    regionalAndTransliteratedKeywords: ['stray dogs', 'kutte ka aatank', 'machar', 'dengue', 'chikungunya', 'naai thollai', 'rabies', 'hospital staff'],
    defaultOfficer: 'Dr. Priya Deshmukh (District Chief Medical Officer)',
    officerPhone: '+91 98200 91823',
  },
  police: {
    department: 'Police Department',
    aliases: ['State Police Force', 'Traffic Police'],
    defaultAction: 'Deploy nighttime PCR beat patrol, enforce traffic regulations, and curb anti-social activities in the area.',
    defaultPriority: 'High',
    deadline: '24 Hours',
    deadlineHours: 24,
    englishKeywords: ['police', 'theft', 'traffic', 'harassment', 'noise', 'alcohol', 'drugs', 'illegal parking', 'crime', 'safety', 'patrol', 'signal', 'speeding', 'robbery', 'unsafe'],
    hindiKeywords: ['पुलिस', 'चोरी', 'सुरक्षा', 'छेड़छाड़', 'नशा', 'ट्रैफिक', 'झगड़ा', 'जाम', 'खतरा', 'अपराध', 'डकैती', 'थाना'],
    tamilKeywords: ['காவல்துறை', 'போலீஸ்', 'திருட்டு', 'போக்குவரத்து', 'பாதுகாப்பு', 'சத்தக் கூச்சல்'],
    regionalAndTransliteratedKeywords: ['police patrol', 'chori', 'traffic jam', 'unsafe area', 'thana', 'police complaint', 'loud music night', 'gundagardi'],
    defaultOfficer: 'Inspector Vikram Singh (Station House Officer / DSP)',
    officerPhone: '+91 98119 00112',
  },
  disaster: {
    department: 'Disaster Management Authority',
    aliases: ['Disaster Management', 'SDMA', 'DDMA'],
    defaultAction: 'Deploy high-capacity diesel de-watering pumps, clear primary storm surge bottlenecks, and mobilize rescue crew.',
    defaultPriority: 'Critical',
    deadline: '12 Hours',
    deadlineHours: 12,
    englishKeywords: ['flooding', 'flood', 'inundation', 'submerged', 'heavy rain', 'cyclone', 'deluge', 'water logging', 'waterlogged', 'disaster', 'rescue', 'landslide'],
    hindiKeywords: ['बाढ़', 'भारी बारिश', 'डूबा', 'रेस्क्यू', 'तूफान', 'जलप्रलय', 'जलजमाव', 'मकान डूबा', 'भूस्खलन'],
    tamilKeywords: ['வெள்ளம்', 'புயல்', 'பேரிடர்', 'மூழ்கியது', 'மீட்பு பணி'],
    regionalAndTransliteratedKeywords: ['baadh', 'jaljamaav', 'flood water', 'ghar me pani', 'waterlogging', 'vella neer', 'storm surge'],
    defaultOfficer: 'Col. Amit Mehra (Disaster Relief Coordinator)',
    officerPhone: '+91 98188 90100',
  },
  transport: {
    department: 'Transport Department',
    aliases: ['State Road Transport', 'RTO'],
    defaultAction: 'Increase bus fleet frequency on affected route, repair damaged bus passenger shelters, and inspect RTO compliance.',
    defaultPriority: 'Medium',
    deadline: '5 Days',
    deadlineHours: 120,
    englishKeywords: ['bus', 'bus stop', 'bus stand', 'transport', 'auto', 'fare', 'conductor', 'route', 'rto', 'overcrowding', 'roadways'],
    hindiKeywords: ['बस', 'परिवहन', 'बस स्टॉप', 'किराया', 'बस स्टैंड', 'कंडक्टर', 'रूट', 'रोडवेज', 'गाड़ी'],
    tamilKeywords: ['பேருந்து', 'பஸ்', 'போக்குவரத்து கழகம்', 'பஸ் நிறுத்தம்', 'பேருந்து வசதி'],
    regionalAndTransliteratedKeywords: ['bus nahi aati', 'bus stop tuta', 'roadways bus', 'transport problem', 'auto meter'],
    defaultOfficer: 'M. Anand (Regional Transport Officer - Operations)',
    officerPhone: '+91 98410 77654',
  },
  education: {
    department: 'Education Department',
    aliases: ['School Education Department'],
    defaultAction: 'Inspect government school infrastructure, resolve mid-day meal quality issues, and repair campus boundaries.',
    defaultPriority: 'Medium',
    deadline: '5 Days',
    deadlineHours: 120,
    englishKeywords: ['school', 'students', 'college', 'classroom', 'teacher', 'midday meal', 'scholarship', 'books', 'headmaster'],
    hindiKeywords: ['स्कूल', 'विद्यालय', 'शिक्षक', 'किताबें', 'मिड डे मील', 'छात्र', 'मास्टर', 'शिक्षा'],
    tamilKeywords: ['பள்ளி', 'பள்ளிக்கூடம்', 'மாணவர்கள்', 'கல்வி', 'வகுப்பறை'],
    regionalAndTransliteratedKeywords: ['school repair', 'teacher absence', 'midday meal kharab', 'vidyalaya', 'classroom छत'],
    defaultOfficer: 'Dr. Sunita Rao (District Educational Officer)',
    officerPhone: '+91 98720 33411',
  },
  revenue: {
    department: 'Revenue Department',
    aliases: ['District Collectorate', 'Tehsildar Office'],
    defaultAction: 'Audit land registry records, resolve demarcation dispute via Tehsildar survey, and issue certified documentation.',
    defaultPriority: 'Low',
    deadline: '14 Days',
    deadlineHours: 336,
    englishKeywords: ['patta', 'chitta', 'land', 'survey', 'encroachment', 'revenue', 'tahsildar', 'tehsildar', 'certificate', 'registry', 'property dispute'],
    hindiKeywords: ['जमीन', 'पटवारी', 'तहसीलदार', 'खतौनी', 'रजिस्ट्री', 'कब्जा', 'प्रमाण पत्र', 'राजस्व'],
    tamilKeywords: ['பட்டா', 'சிட்டா', 'நிலம்', 'வருவாய் துறை', 'வட்டாட்சியர்', 'ஆக்கிரமிப்பு'],
    regionalAndTransliteratedKeywords: ['tehsildar', 'patwari', 'zameen kabza', 'registry', 'khasra khatauni', 'land records'],
    defaultOfficer: 'D. Karthikeyan (Sub-Divisional Magistrate / Tehsildar)',
    officerPhone: '+91 98402 11980',
  },
};

// Major Indian metropolitan and tier-2 locations for auto-extraction
export const INDIAN_KNOWN_LOCATIONS = [
  { name: 'Bandra', city: 'Mumbai', district: 'Mumbai Suburban', state: 'Maharashtra' },
  { name: 'Andheri', city: 'Mumbai', district: 'Mumbai Suburban', state: 'Maharashtra' },
  { name: 'Dadar', city: 'Mumbai', district: 'Mumbai', state: 'Maharashtra' },
  { name: 'Kothrud', city: 'Pune', district: 'Pune', state: 'Maharashtra' },
  { name: 'Connaught Place', city: 'New Delhi', district: 'New Delhi', state: 'Delhi' },
  { name: 'Rohini', city: 'Delhi', district: 'North Delhi', state: 'Delhi' },
  { name: 'Dwarka', city: 'Delhi', district: 'South West Delhi', state: 'Delhi' },
  { name: 'Anna Nagar', city: 'Chennai', district: 'Chennai', state: 'Tamil Nadu' },
  { name: 'Velachery', city: 'Chennai', district: 'Chennai', state: 'Tamil Nadu' },
  { name: 'T. Nagar', city: 'Chennai', district: 'Chennai', state: 'Tamil Nadu' },
  { name: 'Indiranagar', city: 'Bengaluru', district: 'Bengaluru Urban', state: 'Karnataka' },
  { name: 'Whitefield', city: 'Bengaluru', district: 'Bengaluru Urban', state: 'Karnataka' },
  { name: 'Koramangala', city: 'Bengaluru', district: 'Bengaluru Urban', state: 'Karnataka' },
  { name: 'Salt Lake', city: 'Kolkata', district: 'North 24 Parganas', state: 'West Bengal' },
  { name: 'Park Street', city: 'Kolkata', district: 'Kolkata', state: 'West Bengal' },
  { name: 'Banjara Hills', city: 'Hyderabad', district: 'Hyderabad', state: 'Telangana' },
  { name: 'Gachibowli', city: 'Hyderabad', district: 'Ranga Reddy', state: 'Telangana' },
  { name: 'Hazratganj', city: 'Lucknow', district: 'Lucknow', state: 'Uttar Pradesh' },
  { name: 'Gomti Nagar', city: 'Lucknow', district: 'Lucknow', state: 'Uttar Pradesh' },
  { name: 'Sector 18', city: 'Noida', district: 'Noida / Gautam Buddha Nagar', state: 'Uttar Pradesh' },
  { name: 'Navrangpura', city: 'Ahmedabad', district: 'Ahmedabad', state: 'Gujarat' },
  { name: 'Vaishali Nagar', city: 'Jaipur', district: 'Jaipur', state: 'Rajasthan' },
];

/**
 * Intelligent Language Detector
 * Accurately recognizes Devanagari (Hindi/Marathi/Nepali), Tamil, Telugu, Kannada,
 * Malayalam, Bengali, Gujarati, Punjabi, Urdu, Odia, and Transliterated/Mixed Indian languages.
 */
export function detectIndianLanguage(text: string): string {
  if (/[\u0900-\u097F]/.test(text)) return 'Hindi (हिंदी)';
  if (/[\u0B80-\u0BFF]/.test(text)) return 'Tamil (தமிழ்)';
  if (/[\u0C00-\u0C7F]/.test(text)) return 'Telugu (తెలుగు)';
  if (/[\u0C80-\u0CFF]/.test(text)) return 'Kannada (ಕನ್ನಡ)';
  if (/[\u0D00-\u0D7F]/.test(text)) return 'Malayalam (മലയാളം)';
  if (/[\u0980-\u09FF]/.test(text)) return 'Bengali (বাংলা)';
  if (/[\u0A80-\u0AFF]/.test(text)) return 'Gujarati (ગુજરાતી)';
  if (/[\u0A00-\u0A7F]/.test(text)) return 'Punjabi (ਪੰਜਾਬੀ)';
  if (/[\u0600-\u06FF]/.test(text)) return 'Urdu (اردو)';
  if (/[\u0B00-\u0B7F]/.test(text)) return 'Odia (ଓଡ଼ିଆ)';

  // Check for common Hinglish/Tanglish/Indian-English markers
  const lower = text.toLowerCase();
  const mixedWords = [
    'nahi', 'hai', 'kripya', 'paani', 'sadak', 'bijli', 'chal', 'raha', 'bhi',
    'enga', 'theruvilakku', 'aagala', 'panunga', 'kooda', 'romba', 'venum',
    'chahiye', 'karo', 'gaddhe', 'kachra', 'bohot', 'sir ji', 'illai',
  ];
  const isMixed = mixedWords.some((w) => lower.includes(w));
  if (isMixed) {
    return 'Hinglish / Tanglish (Mixed Indian Language)';
  }

  return 'English';
}

/**
 * Intelligent Rule-Based Multilingual Grievance Parser for India
 * Splits multi-issue compound complaints across appropriate national departments.
 */
export function analyzeComplaintRuleBased(
  text: string,
  userLocation?: Partial<LocationInfo>,
  customComplaintId?: string
): AIAnalysisResult {
  const lower = text.toLowerCase();
  const complaintId = customComplaintId || `IND-GRV-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const detectedLanguage = detectIndianLanguage(text);

  // Extract or enhance location based on text mentions
  let extractedLoc: Partial<LocationInfo> = {
    country: 'India',
    state: userLocation?.state || 'Maharashtra',
    district: userLocation?.district || 'Mumbai',
    city: userLocation?.city || 'Mumbai',
    taluk: userLocation?.taluk || 'Bandra',
    area: userLocation?.area || 'Bandra West',
    ward: userLocation?.ward || 'Ward 12',
    latitude: userLocation?.latitude || 19.0596,
    longitude: userLocation?.longitude || 72.8295,
  };

  for (const loc of INDIAN_KNOWN_LOCATIONS) {
    if (lower.includes(loc.name.toLowerCase()) || lower.includes(loc.city.toLowerCase())) {
      extractedLoc = {
        country: 'India',
        state: loc.state,
        district: loc.district,
        city: loc.city,
        taluk: loc.name,
        area: `${loc.name}, ${loc.city}`,
        ward: extractedLoc.ward || 'Ward Central',
        latitude: userLocation?.latitude || 19.0596,
        longitude: userLocation?.longitude || 72.8295,
      };
      break;
    }
  }

  const detectedIssues: DetectedIssue[] = [];
  let issueCounter = 1;

  // Evaluate each department rule against the complaint
  for (const [key, rule] of Object.entries(NATIONAL_DEPARTMENT_RULES)) {
    let matched = false;
    let matchConfidence = 94;

    // Check English keywords
    for (const kw of rule.englishKeywords) {
      if (lower.includes(kw.toLowerCase())) {
        matched = true;
        matchConfidence = 96;
        break;
      }
    }

    // Check Hindi keywords
    if (!matched) {
      for (const kw of rule.hindiKeywords) {
        if (text.includes(kw)) {
          matched = true;
          matchConfidence = 98;
          break;
        }
      }
    }

    // Check Tamil keywords
    if (!matched) {
      for (const kw of rule.tamilKeywords) {
        if (text.includes(kw)) {
          matched = true;
          matchConfidence = 97;
          break;
        }
      }
    }

    // Check Transliterated/Regional keywords
    if (!matched) {
      for (const kw of rule.regionalAndTransliteratedKeywords) {
        if (lower.includes(kw.toLowerCase())) {
          matched = true;
          matchConfidence = 95;
          break;
        }
      }
    }

    if (matched) {
      let priority: Priority = rule.defaultPriority;
      let deadline = rule.deadline;
      let deadlineHours = rule.deadlineHours;
      let action = rule.defaultAction;
      let summary = '';

      // Specific issue summary overrides based on key indicators
      if (key === 'sanitation') {
        if (lower.includes('overflow') || lower.includes('flooding') || text.includes('सीवर') || text.includes('கழிவுநீர்')) {
          summary = 'Sewage Overflow & Blocked Drainage Infrastructure';
          priority = 'Critical';
          deadline = '24 Hours';
          deadlineHours = 24;
          action = 'Deploy high-velocity sewer suction jetting tanker to clear root blockage.';
        } else if (lower.includes('garbage') || lower.includes('kachra') || text.includes('कचरा') || text.includes('குப்பை')) {
          summary = 'Severe Garbage Accumulation & Missed Door-to-Door Collection';
          priority = 'Medium';
          deadline = '48 Hours';
          deadlineHours = 48;
          action = 'Dispatch secondary compacting tipper truck and disinfect collection bin bay.';
        } else {
          summary = 'Stormwater Drainage Clog & Public Health Hazard';
        }
      } else if (key === 'electricity') {
        if (lower.includes('spark') || lower.includes('hanging') || text.includes('तार') || text.includes('மின்கசிவு')) {
          summary = 'Exposed Dangling High-Voltage Cable / Safety Hazard';
          priority = 'Critical';
          deadline = '24 Hours';
          deadlineHours = 24;
          action = 'Isolate feeder section, replace frayed insulation, and re-tension overhead conductor.';
        } else if (lower.includes('transformer') || text.includes('ट्रांसफार्मर')) {
          summary = 'Distribution Transformer Overload & Phase Failure';
          priority = 'High';
          deadline = '48 Hours';
          deadlineHours = 48;
          action = 'Replace thermal cutout fuses and re-balance branch phase load.';
        } else {
          summary = 'Non-Functional Streetlights & Dark Spots in Public Corridor';
        }
      } else if (key === 'pwd') {
        if (lower.includes('pothole') || lower.includes('gaddhe') || text.includes('गड्ढा') || text.includes('பள்ளம்')) {
          summary = 'Deep Vehicle-Damaging Potholes & Broken Road Surface';
          action = 'Excavate failed base course, pack graded stone ballast, and seal with hot bitumen overlay.';
        } else {
          summary = 'Damaged Arterial Road Infrastructure & Public Transit Hazard';
        }
      } else if (key === 'water') {
        if (lower.includes('leak') || lower.includes('pipe') || text.includes('लीकेज') || text.includes('கசிவு')) {
          summary = 'Pressurized Potable Water Main Pipeline Rupture & Wastage';
          priority = 'High';
          deadline = '48 Hours';
          deadlineHours = 48;
          action = 'Excavate pipeline trench, weld mechanical clamp collar sleeve, and backfill.';
        } else if (lower.includes('dirty') || lower.includes('contamination') || text.includes('गंदा') || text.includes('துர்நாற்றம்')) {
          summary = 'Cross-Contamination in Domestic Drinking Water Supply';
          priority = 'Critical';
          deadline = '24 Hours';
          deadlineHours = 24;
          action = 'Halt branch valve line, conduct chlorination shock treatment, and take laboratory samples.';
        } else {
          summary = 'Interrupted Drinking Water Distribution & Pressure Deficit';
        }
      } else if (key === 'health') {
        if (lower.includes('dog') || lower.includes('bite') || text.includes('कुत्ता') || text.includes('நாய்')) {
          summary = 'Aggressive Stray Dog Menace & Rabies Safety Hazard';
          action = 'Deploy municipal animal control squad for vaccination, sterilization, and safety tagging.';
        } else {
          summary = 'Vector-Borne Mosquito Breeding & Public Health Outbreak Risk';
        }
      } else if (key === 'police') {
        summary = 'Public Safety Concern & Nighttime Security Patrolling Request';
      } else if (key === 'disaster') {
        summary = 'Severe Monsoon Water Inundation & Civic Deluge Emergency';
        priority = 'Critical';
        deadline = '12 Hours';
        deadlineHours = 12;
      } else if (key === 'transport') {
        summary = 'Irregular Public Bus Transit & Commuter Congestion';
      } else if (key === 'education') {
        summary = 'Government School Infrastructure & Student Safety Query';
      } else if (key === 'revenue') {
        summary = 'Land Boundary Verification & Administrative Record Grievance';
      }

      detectedIssues.push({
        id: `${complaintId}-ISSUE-0${issueCounter++}`,
        issueSummary: summary,
        department: rule.department,
        requiredAction: action,
        deadline,
        deadlineHours,
        priority,
        confidenceScore: matchConfidence,
        status: 'Pending',
        assignedOfficer: rule.defaultOfficer,
        officerPhone: rule.officerPhone,
        createdAt: new Date().toISOString(),
      });
    }
  }

  // If no specific keywords triggered, create a comprehensive Municipal Civic Issue
  if (detectedIssues.length === 0) {
    detectedIssues.push({
      id: `${complaintId}-ISSUE-01`,
      issueSummary: 'Citizen Civic Infrastructure & Public Utility Grievance',
      department: 'Municipal Corporation / Sanitation',
      requiredAction: 'Conduct on-site inspection by designated ward engineer within SLA window.',
      deadline: '7 Days',
      deadlineHours: 168,
      priority: 'Medium',
      confidenceScore: 89,
      status: 'Pending',
      assignedOfficer: 'R. K. Sharma (Chief Municipal Health Officer)',
      officerPhone: '+91 98100 45210',
      createdAt: new Date().toISOString(),
    });
  }

  const deptCount = new Set(detectedIssues.map((i) => i.department)).size;
  const summary = `AI detected ${detectedIssues.length} distinct civic issues routed across ${deptCount} government departments with citizen charter SLAs.`;

  return {
    complaint_id: complaintId,
    original_complaint: text,
    detected_language: detectedLanguage,
    location: extractedLoc,
    issues_detected: detectedIssues,
    summary,
    aiEngineUsed: 'CIVIE PRAXIS National Multilingual NLP Engine (Demo AI Mode)',
  };
}

/**
 * Calculates similarity between two complaints for duplicate detection
 */
export function calculateComplaintSimilarity(text1: string, text2: string): number {
  const getTokens = (str: string) =>
    new Set(
      str
        .toLowerCase()
        .replace(/[^a-z0-9\u0900-\u097F\u0B80-\u0BFF\s]/g, '')
        .split(/\s+/)
        .filter((w) => w.length > 2)
    );

  const tokens1 = getTokens(text1);
  const tokens2 = getTokens(text2);

  if (tokens1.size === 0 || tokens2.size === 0) return 0;

  let intersection = 0;
  for (const token of tokens1) {
    if (tokens2.has(token)) {
      intersection++;
    }
  }

  const union = new Set([...tokens1, ...tokens2]).size;
  return Math.round((intersection / union) * 100);
}
