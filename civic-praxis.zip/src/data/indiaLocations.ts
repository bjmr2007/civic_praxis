export interface StateData {
  name: string;
  code: string;
  stateName?: string;
  stateCode?: string;
  type: 'State' | 'Union Territory';
  capital: string;
  districts: string[];
  mapCoords: { lat: number; lng: number };
}

export const INDIAN_STATES: StateData[] = [
  {
    name: 'Maharashtra',
    code: 'MH',
    type: 'State',
    capital: 'Mumbai',
    districts: [
      'Ahmednagar', 'Akola', 'Amravati', 'Aurangabad (Chhatrapati Sambhajinagar)', 'Beed', 'Bhandara',
      'Buldhana', 'Chandrapur', 'Dhule', 'Gadchiroli', 'Gondia', 'Hingoli', 'Jalgaon', 'Jalna',
      'Kolhapur', 'Latur', 'Mumbai', 'Mumbai Suburban', 'Nagpur', 'Nanded', 'Nandurbar', 'Nashik',
      'Osmanabad (Dharashiv)', 'Palghar', 'Parbhani', 'Pune', 'Raigad', 'Ratnagiri', 'Sangli',
      'Satara', 'Sindhudurg', 'Solapur', 'Thane', 'Wardha', 'Washim', 'Yavatmal'
    ],
    mapCoords: { lat: 19.7515, lng: 75.7139 },
  },
  {
    name: 'Delhi',
    code: 'DL',
    type: 'Union Territory',
    capital: 'New Delhi',
    districts: [
      'Central Delhi', 'East Delhi', 'New Delhi', 'North Delhi', 'North East Delhi',
      'North West Delhi', 'Shahdara', 'South Delhi', 'South East Delhi', 'South West Delhi', 'West Delhi'
    ],
    mapCoords: { lat: 28.7041, lng: 77.1025 },
  },
  {
    name: 'Tamil Nadu',
    code: 'TN',
    type: 'State',
    capital: 'Chennai',
    districts: [
      'Ariyalur', 'Chengalpattu', 'Chennai', 'Coimbatore', 'Cuddalore', 'Dharmapuri', 'Dindigul',
      'Erode', 'Kallakurichi', 'Kanchipuram', 'Kanyakumari', 'Karur', 'Krishnagiri', 'Madurai',
      'Mayiladuthurai', 'Nagapattinam', 'Namakkal', 'Nilgiris', 'Perambalur', 'Pudukkottai',
      'Ramanathapuram', 'Ranipet', 'Salem', 'Sivaganga', 'Tenkasi', 'Thanjavur', 'Theni',
      'Thoothukudi', 'Tiruchirappalli', 'Tirunelveli', 'Tirupathur', 'Tiruppur', 'Tiruvallur',
      'Tiruvannamalai', 'Tiruvarur', 'Vellore', 'Viluppuram', 'Virudhunagar'
    ],
    mapCoords: { lat: 11.1271, lng: 78.6569 },
  },
  {
    name: 'Karnataka',
    code: 'KA',
    type: 'State',
    capital: 'Bengaluru',
    districts: [
      'Bagalkote', 'Ballari', 'Belagavi', 'Bengaluru Rural', 'Bengaluru Urban', 'Bidar', 'Chamarajanagar',
      'Chikkaballapura', 'Chikkamagaluru', 'Chitradurga', 'Dakshina Kannada (Mangaluru)', 'Davanagere',
      'Dharwad', 'Gadag', 'Hassan', 'Haveri', 'Kalaburagi', 'Kodagu', 'Kolar', 'Koppal', 'Mandya',
      'Mysuru', 'Raichur', 'Ramanagara', 'Shivamogga', 'Tumakuru', 'Udupi', 'Uttara Kannada',
      'Vijayanagara', 'Vijayapura', 'Yadgir'
    ],
    mapCoords: { lat: 15.3173, lng: 75.7139 },
  },
  {
    name: 'Uttar Pradesh',
    code: 'UP',
    type: 'State',
    capital: 'Lucknow',
    districts: [
      'Agra', 'Aligarh', 'Ambedkar Nagar', 'Amethi', 'Amroha', 'Auraiya', 'Ayodhya', 'Azamgarh',
      'Baghpat', 'Bahraich', 'Ballia', 'Balrampur', 'Banda', 'Barabanki', 'Bareilly', 'Basti',
      'Bhadohi', 'Bijnor', 'Budaun', 'Bulandshahr', 'Chandauli', 'Chitrakoot', 'Deoria', 'Etah',
      'Etawah', 'Farrukhabad', 'Fatehpur', 'Firozabad', 'Gautam Buddha Nagar (Noida)', 'Ghaziabad',
      'Ghazipur', 'Gonda', 'Gorakhpur', 'Hamirpur', 'Hapur', 'Hardoi', 'Hathras', 'Jalaun', 'Jaunpur',
      'Jhansi', 'Kannauj', 'Kanpur Dehat', 'Kanpur Nagar', 'Kasganj', 'Kaushambi', 'Kushinagar',
      'Lakhimpur Kheri', 'Lalitpur', 'Lucknow', 'Maharajganj', 'Mahoba', 'Mainpuri', 'Mathura',
      'Mau', 'Meerut', 'Mirzapur', 'Moradabad', 'Muzaffarnagar', 'Pilibhit', 'Pratapgarh', 'Prayagraj',
      'Raebareli', 'Rampur', 'Saharanpur', 'Sambhal', 'Sant Kabir Nagar', 'Shahjahanpur', 'Shamli',
      'Shravasti', 'Siddharthnagar', 'Sitapur', 'Sonbhadra', 'Sultanpur', 'Unnao', 'Varanasi'
    ],
    mapCoords: { lat: 26.8467, lng: 80.9462 },
  },
  {
    name: 'Gujarat',
    code: 'GJ',
    type: 'State',
    capital: 'Gandhinagar',
    districts: [
      'Ahmedabad', 'Amreli', 'Anand', 'Aravalli', 'Banaskantha', 'Bharuch', 'Bhavnagar', 'Botad',
      'Chhota Udaipur', 'Dahod', 'Dang', 'Devbhumi Dwarka', 'Gandhinagar', 'Gir Somnath', 'Jamnagar',
      'Junagadh', 'Kheda', 'Kutch', 'Mahisagar', 'Mehsana', 'Morbi', 'Narmada', 'Navsari',
      'Panchmahal', 'Patan', 'Porbandar', 'Rajkot', 'Sabarkantha', 'Surat', 'Surendranagar',
      'Tapi', 'Vadodara', 'Valsad'
    ],
    mapCoords: { lat: 22.2587, lng: 71.1924 },
  },
  {
    name: 'Telangana',
    code: 'TG',
    type: 'State',
    capital: 'Hyderabad',
    districts: [
      'Adilabad', 'Bhadradri Kothagudem', 'Hanamkonda', 'Hyderabad', 'Jagtial', 'Jangaon',
      'Jayashankar Bhupalpally', 'Jogulamba Gadwal', 'Kamareddy', 'Karimnagar', 'Khammam',
      'Kumuram Bheem Asifabad', 'Mahabubabad', 'Mahabubnagar', 'Mancherial', 'Medak',
      'Medchal-Malkajgiri', 'Mulugu', 'Nagarkurnool', 'Nalgonda', 'Narayanpet', 'Nirmal',
      'Nizamabad', 'Peddapalli', 'Rajanna Sircilla', 'Ranga Reddy', 'Sangareddy', 'Siddipet',
      'Suryapet', 'Vikarabad', 'Wanaparthy', 'Warangal', 'Yadadri Bhuvanagiri'
    ],
    mapCoords: { lat: 18.1124, lng: 79.0193 },
  },
  {
    name: 'West Bengal',
    code: 'WB',
    type: 'State',
    capital: 'Kolkata',
    districts: [
      'Alipurduar', 'Bankura', 'Birbhum', 'Cooch Behar', 'Dakshin Dinajpur', 'Darjeeling',
      'Hooghly', 'Howrah', 'Jalpaiguri', 'Jhargram', 'Kalimpong', 'Kolkata', 'Malda',
      'Murshidabad', 'Nadia', 'North 24 Parganas', 'Paschim Bardhaman', 'Paschim Medinipur',
      'Purba Bardhaman', 'Purba Medinipur', 'Purulia', 'South 24 Parganas', 'Uttar Dinajpur'
    ],
    mapCoords: { lat: 22.9868, lng: 87.855 },
  },
  {
    name: 'Rajasthan',
    code: 'RJ',
    type: 'State',
    capital: 'Jaipur',
    districts: [
      'Ajmer', 'Alwar', 'Banswara', 'Baran', 'Barmer', 'Bharatpur', 'Bhilwara', 'Bikaner',
      'Bundi', 'Chittorgarh', 'Churu', 'Dausa', 'Dholpur', 'Dungarpur', 'Hanumangarh', 'Jaipur',
      'Jaisalmer', 'Jalore', 'Jhalawar', 'Jhunjhunu', 'Jodhpur', 'Karauli', 'Kota', 'Nagaur',
      'Pali', 'Pratapgarh', 'Rajsamand', 'Sawai Madhopur', 'Sikar', 'Sirohi', 'Sri Ganganagar',
      'Tonk', 'Udaipur'
    ],
    mapCoords: { lat: 27.0238, lng: 74.2179 },
  },
  {
    name: 'Kerala',
    code: 'KL',
    type: 'State',
    capital: 'Thiruvananthapuram',
    districts: [
      'Alappuzha', 'Ernakulam (Kochi)', 'Idukki', 'Kannur', 'Kasaragod', 'Kollam', 'Kottayam',
      'Kozhikode', 'Malappuram', 'Palakkad', 'Pathanamthitta', 'Thiruvananthapuram', 'Thrissur', 'Wayanad'
    ],
    mapCoords: { lat: 10.8505, lng: 76.2711 },
  },
  {
    name: 'Andhra Pradesh',
    code: 'AP',
    type: 'State',
    capital: 'Amaravati',
    districts: [
      'Alluri Sitharama Raju', 'Anakapalli', 'Ananthapuramu', 'Annamayya', 'Bapatla', 'Chittoor',
      'Dr. B.R. Ambedkar Konaseema', 'East Godavari', 'Eluru', 'Guntur', 'Kakinada', 'Krishna',
      'Kurnool', 'Nandyal', 'NTR (Vijayawada)', 'Palnadu', 'Parvathipuram Manyam', 'Prakasam',
      'Sri Potti Sriramulu Nellore', 'Sri Sathya Sai', 'Srikakulam', 'Tirupati', 'Visakhapatnam',
      'Vizianagaram', 'West Godavari', 'YSR Kadapa'
    ],
    mapCoords: { lat: 15.9129, lng: 79.74 },
  },
  {
    name: 'Madhya Pradesh',
    code: 'MP',
    type: 'State',
    capital: 'Bhopal',
    districts: [
      'Agar Malwa', 'Alirajpur', 'Anuppur', 'Ashoknagar', 'Balaghat', 'Barwani', 'Betul', 'Bhind',
      'Bhopal', 'Burhanpur', 'Chhatarpur', 'Chhindwara', 'Damoh', 'Datia', 'Dewas', 'Dhar',
      'Dindori', 'Guna', 'Gwalior', 'Harda', 'Hoshangabad (Narmadapuram)', 'Indore', 'Jabalpur',
      'Jhabua', 'Katni', 'Khandwa', 'Khargone', 'Mandla', 'Mandsaur', 'Morena', 'Narsinghpur',
      'Neemuch', 'Niwari', 'Panna', 'Raisen', 'Rajgarh', 'Ratlam', 'Rewa', 'Sagar', 'Satna',
      'Sehore', 'Seoni', 'Shahdol', 'Shajapur', 'Sheopur', 'Shivpuri', 'Sidhi', 'Singrauli',
      'Tikamgarh', 'Ujjain', 'Umaria', 'Vidisha'
    ],
    mapCoords: { lat: 22.9734, lng: 78.6569 },
  },
  {
    name: 'Bihar',
    code: 'BR',
    type: 'State',
    capital: 'Patna',
    districts: [
      'Araria', 'Arwal', 'Aurangabad', 'Banka', 'Begusarai', 'Bhagalpur', 'Bhojpur (Arrah)',
      'Buxar', 'Darbhanga', 'East Champaran (Motihari)', 'Gaya', 'Gopalganj', 'Jamui', 'Jehanabad',
      'Kaimur (Bhabua)', 'Katihar', 'Khagaria', 'Kishanganj', 'Lakhisarai', 'Madhepura',
      'Madhubani', 'Munger', 'Muzaffarpur', 'Nalanda (Bihar Sharif)', 'Nawada', 'Patna',
      'Purnia', 'Rohtas (Sasaram)', 'Saharsa', 'Samastipur', 'Saran (Chhapra)', 'Sheikhpura',
      'Sheohar', 'Sitamarhi', 'Siwan', 'Supaul', 'Vaishali (Hajipur)', 'West Champaran (Bettiah)'
    ],
    mapCoords: { lat: 25.0961, lng: 85.3131 },
  },
  {
    name: 'Punjab',
    code: 'PB',
    type: 'State',
    capital: 'Chandigarh',
    districts: [
      'Amritsar', 'Barnala', 'Bathinda', 'Faridkot', 'Fatehgarh Sahib', 'Fazilka', 'Ferozepur',
      'Gurdaspur', 'Hoshiarpur', 'Jalandhar', 'Kapurthala', 'Ludhiana', 'Malerkotla', 'Mansa',
      'Moga', 'Mohali (SAS Nagar)', 'Muktsar', 'Pathankot', 'Patiala', 'Rupnagar', 'Sangrur',
      'Shaheed Bhagat Singh Nagar (Nawanshahr)', 'Tarn Taran'
    ],
    mapCoords: { lat: 31.1471, lng: 75.3412 },
  },
  {
    name: 'Haryana',
    code: 'HR',
    type: 'State',
    capital: 'Chandigarh',
    districts: [
      'Ambala', 'Bhiwani', 'Charkhi Dadri', 'Faridabad', 'Fatehabad', 'Gurugram', 'Hisar',
      'Jhajjar', 'Jind', 'Kaithal', 'Karnal', 'Kurukshetra', 'Mahendragarh', 'Nuh', 'Palwal',
      'Panchkula', 'Panipat', 'Rewari', 'Rohtak', 'Sirsa', 'Sonipat', 'Yamunanagar'
    ],
    mapCoords: { lat: 29.0588, lng: 76.0856 },
  },
  {
    name: 'Odisha',
    code: 'OD',
    type: 'State',
    capital: 'Bhubaneswar',
    districts: [
      'Angul', 'Balangir', 'Balasore (Baleswar)', 'Bargarh', 'Bhadrak', 'Boudh', 'Cuttack',
      'Deogarh', 'Dhenkanal', 'Gajapati', 'Ganjam', 'Jagatsinghpur', 'Jajpur', 'Jharsuguda',
      'Kalahandi', 'Kandhamal', 'Kendrapara', 'Kendujhar (Keonjhar)', 'Khordha (Bhubaneswar)',
      'Koraput', 'Malkangiri', 'Mayurbhanj', 'Nabarangpur', 'Nayagarh', 'Nuapada', 'Puri',
      'Rayagada', 'Sambalpur', 'Subarnapur (Sonepur)', 'Sundargarh (Rourkela)'
    ],
    mapCoords: { lat: 20.9517, lng: 85.0985 },
  },
  {
    name: 'Assam',
    code: 'AS',
    type: 'State',
    capital: 'Dispur',
    districts: [
      'Baksa', 'Barpeta', 'Biswanath', 'Bongaigaon', 'Cachar (Silchar)', 'Charaideo', 'Chirang',
      'Darrang', 'Dhemaji', 'Dhubri', 'Dibrugarh', 'Dima Hasao', 'Goalpara', 'Golaghat', 'Hailakandi',
      'Hojai', 'Jorhat', 'Kamrup', 'Kamrup Metropolitan (Guwahati)', 'Karbi Anglong', 'Karimganj',
      'Kokrajhar', 'Lakhimpur', 'Majuli', 'Morigaon', 'Nagaon', 'Nalbari', 'Sivasagar', 'Sonitpur',
      'South Salmara-Mankachar', 'Tinsukia', 'Udalguri', 'West Karbi Anglong'
    ],
    mapCoords: { lat: 26.2006, lng: 92.9376 },
  },
  {
    name: 'Jharkhand',
    code: 'JH',
    type: 'State',
    capital: 'Ranchi',
    districts: [
      'Bokaro', 'Chatra', 'Deoghar', 'Dhanbad', 'Dumka', 'East Singhbhum (Jamshedpur)', 'Garhwa',
      'Giridih', 'Godda', 'Gumla', 'Hazaribagh', 'Jamtara', 'Khunti', 'Koderma', 'Latehar',
      'Lohardaga', 'Pakur', 'Palamu', 'Ramgarh', 'Ranchi', 'Sahibganj', 'Seraikela Kharsawan',
      'Simdega', 'West Singhbhum'
    ],
    mapCoords: { lat: 23.6102, lng: 85.2799 },
  },
  {
    name: 'Chhattisgarh',
    code: 'CG',
    type: 'State',
    capital: 'Raipur',
    districts: [
      'Balod', 'Baloda Bazar', 'Balrampur', 'Bastar (Jagdalpur)', 'Bemetara', 'Bijapur', 'Bilaspur',
      'Dantewada', 'Dhamtari', 'Durg', 'Gariaband', 'Gaurela-Pendra-Marwahi', 'Janjgir-Champa',
      'Jashpur', 'Kabirdham (Kawardha)', 'Kanker', 'Khairagarh-Chhuikhadan-Gandai', 'Kondagaon',
      'Korba', 'Koriya', 'Mahasamund', 'Manendragarh-Chirmiri-Bharatpur', 'Mohla-Manpur-Ambagarh Chowki',
      'Mungeli', 'Narayanpur', 'Raigarh', 'Raipur', 'Rajnandgaon', 'Sakti', 'Sarangarh-Bilaigarh',
      'Sukma', 'Surajpur', 'Surguja (Ambikapur)'
    ],
    mapCoords: { lat: 21.2787, lng: 81.8661 },
  },
  {
    name: 'Uttarakhand',
    code: 'UK',
    type: 'State',
    capital: 'Dehradun',
    districts: [
      'Almora', 'Bageshwar', 'Chamoli', 'Champawat', 'Dehradun', 'Haridwar', 'Nainital',
      'Pauri Garhwal', 'Pithoragarh', 'Rudraprayag', 'Tehri Garhwal', 'Udham Singh Nagar', 'Uttarkashi'
    ],
    mapCoords: { lat: 30.0668, lng: 79.0193 },
  },
  {
    name: 'Himachal Pradesh',
    code: 'HP',
    type: 'State',
    capital: 'Shimla',
    districts: [
      'Bilaspur', 'Chamba', 'Hamirpur', 'Kangra (Dharamshala)', 'Kinnaur', 'Kullu', 'Lahaul and Spiti',
      'Mandi', 'Shimla', 'Sirmaur', 'Solan', 'Una'
    ],
    mapCoords: { lat: 31.1048, lng: 77.1734 },
  },
  {
    name: 'Goa',
    code: 'GA',
    type: 'State',
    capital: 'Panaji',
    districts: ['North Goa (Panaji)', 'South Goa (Margao)'],
    mapCoords: { lat: 15.2993, lng: 74.124 },
  },
  {
    name: 'Jammu and Kashmir',
    code: 'JK',
    type: 'Union Territory',
    capital: 'Srinagar / Jammu',
    districts: [
      'Anantnag', 'Bandipora', 'Baramulla', 'Budgam', 'Doda', 'Ganderbal', 'Jammu', 'Kathua',
      'Kishtwar', 'Kulgam', 'Kupwara', 'Poonch', 'Pulwama', 'Rajouri', 'Ramban', 'Reasi',
      'Samba', 'Shopian', 'Srinagar', 'Udhampur'
    ],
    mapCoords: { lat: 33.7782, lng: 76.5762 },
  },
  {
    name: 'Ladakh',
    code: 'LA',
    type: 'Union Territory',
    capital: 'Leh',
    districts: ['Leh', 'Kargil'],
    mapCoords: { lat: 34.1526, lng: 77.5771 },
  },
  {
    name: 'Tripura',
    code: 'TR',
    type: 'State',
    capital: 'Agartala',
    districts: [
      'Dhalai', 'Gomati', 'Khowai', 'North Tripura', 'Sepahijala', 'South Tripura', 'Unakoti', 'West Tripura (Agartala)'
    ],
    mapCoords: { lat: 23.8315, lng: 91.2868 },
  },
  {
    name: 'Meghalaya',
    code: 'ML',
    type: 'State',
    capital: 'Shillong',
    districts: [
      'East Garo Hills', 'East Jaintia Hills', 'East Khasi Hills (Shillong)', 'Eastern West Khasi Hills',
      'North Garo Hills', 'Ri-Bhoi', 'South Garo Hills', 'South West Garo Hills', 'South West Khasi Hills',
      'West Garo Hills', 'West Jaintia Hills', 'West Khasi Hills'
    ],
    mapCoords: { lat: 25.467, lng: 91.3662 },
  },
  {
    name: 'Manipur',
    code: 'MN',
    type: 'State',
    capital: 'Imphal',
    districts: [
      'Bishnupur', 'Chandel', 'Churachandpur', 'Imphal East', 'Imphal West', 'Jiribam', 'Kakching',
      'Kamjong', 'Kangpokpi', 'Noney', 'Pherzawl', 'Senapati', 'Tamenglong', 'Tengnoupal', 'Thoubal', 'Ukhrul'
    ],
    mapCoords: { lat: 24.6637, lng: 93.9063 },
  },
  {
    name: 'Nagaland',
    code: 'NL',
    type: 'State',
    capital: 'Kohima',
    districts: [
      'Chümoukedima', 'Dimapur', 'Kiphire', 'Kohima', 'Longleng', 'Mokokchung', 'Mon', 'Niuland',
      'Noklak', 'Peren', 'Phek', 'Shamator', 'Tseminyü', 'Tuensang', 'Wokha', 'Zünheboto'
    ],
    mapCoords: { lat: 26.1584, lng: 94.5624 },
  },
  {
    name: 'Mizoram',
    code: 'MZ',
    type: 'State',
    capital: 'Aizawl',
    districts: [
      'Aizawl', 'Champhai', 'Hnahthial', 'Khawzawl', 'Kolasib', 'Lawngtlai', 'Lunglei', 'Mamit',
      'Saitual', 'Serchhip', 'Siaha'
    ],
    mapCoords: { lat: 23.1645, lng: 92.9376 },
  },
  {
    name: 'Arunachal Pradesh',
    code: 'AR',
    type: 'State',
    capital: 'Itanagar',
    districts: [
      'Anjaw', 'Changlang', 'Dibang Valley', 'East Kameng', 'East Siang', 'Kamle', 'Kra Daadi',
      'Kurung Kumey', 'Leparada', 'Lohit', 'Longding', 'Lower Dibang Valley', 'Lower Siang',
      'Lower Subansiri', 'Namsai', 'Pakke Kessang', 'Papum Pare (Itanagar)', 'Shi Yomi', 'Siang',
      'Tawang', 'Tirap', 'Upper Siang', 'Upper Subansiri', 'West Kameng', 'West Siang'
    ],
    mapCoords: { lat: 28.218, lng: 94.7278 },
  },
  {
    name: 'Sikkim',
    code: 'SK',
    type: 'State',
    capital: 'Gangtok',
    districts: [
      'Gangtok (East Sikkim)', 'Gyalshing (West Sikkim)', 'Mangan (North Sikkim)', 'Namchi (South Sikkim)',
      'Pakyong', 'Soreng'
    ],
    mapCoords: { lat: 27.533, lng: 88.5122 },
  },
  {
    name: 'Chandigarh',
    code: 'CH',
    type: 'Union Territory',
    capital: 'Chandigarh',
    districts: ['Chandigarh Central', 'Chandigarh East', 'Chandigarh South', 'Chandigarh North', 'Chandigarh West'],
    mapCoords: { lat: 30.7333, lng: 76.7794 },
  },
  {
    name: 'Puducherry',
    code: 'PY',
    type: 'Union Territory',
    capital: 'Puducherry',
    districts: ['Puducherry', 'Karaikal', 'Mahe', 'Yanam'],
    mapCoords: { lat: 11.9416, lng: 79.8083 },
  },
  {
    name: 'Andaman and Nicobar Islands',
    code: 'AN',
    type: 'Union Territory',
    capital: 'Port Blair',
    districts: ['Nicobar', 'North and Middle Andaman', 'South Andaman (Port Blair)'],
    mapCoords: { lat: 11.7401, lng: 92.6586 },
  },
  {
    name: 'Dadra and Nagar Haveli and Daman and Diu',
    code: 'DNHDD',
    type: 'Union Territory',
    capital: 'Daman',
    districts: ['Dadra and Nagar Haveli (Silvassa)', 'Daman', 'Diu'],
    mapCoords: { lat: 20.4283, lng: 72.8397 },
  },
  {
    name: 'Lakshadweep',
    code: 'LD',
    type: 'Union Territory',
    capital: 'Kavaratti',
    districts: ['Lakshadweep (Kavaratti)', 'Agatti', 'Andrott', 'Minicoy'],
    mapCoords: { lat: 10.5667, lng: 72.6417 },
  },
];

// Populate alias properties
INDIAN_STATES.forEach((s) => {
  s.stateName = s.name;
  s.stateCode = s.code;
});

export const ALL_INDIAN_LANGUAGES = [
  { code: 'Auto Detect', label: 'Auto Detect (स्वचालित / தானியங்கி)' },
  { code: 'English', label: 'English' },
  { code: 'Hindi', label: 'हिंदी (Hindi)' },
  { code: 'Tamil', label: 'தமிழ் (Tamil)' },
  { code: 'Telugu', label: 'తెలుగు (Telugu)' },
  { code: 'Kannada', label: 'ಕನ್ನಡ (Kannada)' },
  { code: 'Malayalam', label: 'മലയാളം (Malayalam)' },
  { code: 'Bengali', label: 'বাংলা (Bengali)' },
  { code: 'Marathi', label: 'मराठी (Marathi)' },
  { code: 'Gujarati', label: 'ગુજરાતી (Gujarati)' },
  { code: 'Odia', label: 'ଓଡ଼ିଆ (Odia)' },
  { code: 'Punjabi', label: 'ਪੰਜਾਬੀ (Punjabi)' },
  { code: 'Assamese', label: 'অসমীয়া (Assamese)' },
  { code: 'Urdu', label: 'اردو (Urdu)' },
];

export const NATIONAL_DEPARTMENTS_CONFIG = [
  {
    name: 'Water Supply Department',
    aliases: ['Jal Board', 'Water Board', 'Piped Water Supply', 'PHE', 'TWAD', 'BWSSB', 'DJB', 'Water Works'],
    icon: 'Droplets',
    slaStandard: '24 Hours',
    helpline: '1916',
    headOfficer: 'Chief Hydraulic Engineer (Water Distribution)',
    description: 'Mandated for drinking water pipelines, supply interruptions, pressure drops, contaminated water, and booster pumps.',
  },
  {
    name: 'Electricity Department',
    aliases: ['DISCOM', 'Power Grid', 'MSEB', 'BESCOM', 'TANGEDCO', 'TSSPDCL', 'UPPCL', 'State Electricity Board', 'Power Distribution'],
    icon: 'Zap',
    slaStandard: '6 Hours (Faults) / 24 Hours (Transformers)',
    helpline: '1912',
    headOfficer: 'Executive Engineer (Distribution & Sub-Stations)',
    description: 'Statutory authority over power outages, hanging cables, blown transformers, feeder line trips, and voltage fluctuations.',
  },
  {
    name: 'Public Works Department (PWD)',
    aliases: ['PWD', 'Highways', 'Roads & Buildings', 'NHAI', 'State PWD', 'Infrastructure Board'],
    icon: 'Construction',
    slaStandard: '48 Hours (Potholes) / 7 Days (Structural)',
    helpline: '1800-11-2026',
    headOfficer: 'Superintending Engineer (Roads & Bridges)',
    description: 'Responsible for arterial roads, pothole repairs, bridges, flyovers, storm water drains, and state highway maintenance.',
  },
  {
    name: 'Municipal Corporation / Sanitation',
    aliases: ['Nagar Nigam', 'Municipal Council', 'Sanitation Dept', 'BBMP', 'BMC', 'GCC', 'MCD', 'Waste Management', 'Solid Waste'],
    icon: 'Trash2',
    slaStandard: '12 Hours (Garbage) / 24 Hours (Sewage)',
    helpline: '14420',
    headOfficer: 'Chief Municipal Health & Sanitation Officer',
    description: 'Handles municipal garbage clearance, open dumping, sewer line blockages, street sweeping, and vector pest control.',
  },
  {
    name: 'Public Health Department',
    aliases: ['Health Dept', 'CMO', 'Vector Control', 'Civil Hospital', 'Epidemic Control'],
    icon: 'HeartPulse',
    slaStandard: '24 Hours',
    helpline: '104',
    headOfficer: 'Chief Medical Officer (CMO)',
    description: 'Oversees public health emergencies, dengue/malaria fogging, government dispensaries, and sanitation inspections.',
  },
  {
    name: 'Police & Traffic Department',
    aliases: ['Traffic Police', 'Local Police Station', 'Patrolling Squad', 'Law & Order'],
    icon: 'Shield',
    slaStandard: 'Immediate / 2 Hours',
    helpline: '112 / 100',
    headOfficer: 'Deputy Commissioner of Police (DCP Traffic & Patrol)',
    description: 'Traffic gridlocks, illegal parking blocking roads, night patrolling, noise pollution, and civic safety hazards.',
  },
  {
    name: 'Revenue & Land Administration',
    aliases: ['Revenue Dept', 'Tehsildar', 'Taluk Office', 'Land Records', 'Encroachment Wing'],
    icon: 'Landmark',
    slaStandard: '7 Days',
    helpline: '1800-425-0001',
    headOfficer: 'Sub-Divisional Magistrate (SDM) / Tehsildar',
    description: 'Public land encroachments, drainage boundary disputes, registry certifications, and survey verifications.',
  },
  {
    name: 'Transport Department',
    aliases: ['State Transport', 'RTO', 'City Bus Service', 'Metro Rail', 'BMTC', 'BEST', 'DTC'],
    icon: 'Bus',
    slaStandard: '48 Hours',
    helpline: '1800-200-0111',
    headOfficer: 'Regional Transport Officer (RTO)',
    description: 'Bus stop shelter maintenance, public transit frequency, auto/taxi fare meter grievances, and zebra crossings.',
  },
  {
    name: 'Education & Schools Directorate',
    aliases: ['Education Dept', 'DEO', 'School Education', 'Zilla Parishad Schools'],
    icon: 'GraduationCap',
    slaStandard: '3 Days',
    helpline: '1800-11-2004',
    headOfficer: 'District Education Officer (DEO)',
    description: 'Safety hazards around schools, mid-day meal grievances, school infrastructure, and water/sanitation in educational zones.',
  },
  {
    name: 'Disaster Management Authority',
    aliases: ['SDMA', 'DDMA', 'NDRF', 'Civil Defense', 'Flood Control Room'],
    icon: 'Flame',
    slaStandard: 'Immediate (< 1 Hour)',
    helpline: '1077 / 1070',
    headOfficer: 'District Disaster Management Officer (DDMO)',
    description: 'Monsoon waterlogging, cyclone relief, building collapses, tree falls blocking emergency roads, and crisis logistics.',
  },
];
