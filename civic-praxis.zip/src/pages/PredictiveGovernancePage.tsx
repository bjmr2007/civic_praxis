import React, { useState } from 'react';
import { PredictiveRisk } from '../types';
import {
  Sparkles,
  AlertTriangle,
  Flame,
  CloudRain,
  Zap,
  Droplets,
  ShieldCheck,
  Send,
  CheckCircle2,
  Clock,
  Building2,
  MapPin,
  TrendingUp,
} from 'lucide-react';

interface PredictiveGovernancePageProps {
  predictiveRisks: PredictiveRisk[];
  onDispatchAction: (riskId: string) => void;
}

export const PredictiveGovernancePage: React.FC<PredictiveGovernancePageProps> = ({
  predictiveRisks,
  onDispatchAction,
}) => {
  const [dispatchedMap, setDispatchedMap] = useState<Record<string, boolean>>({});

  const handleDispatch = (riskId: string) => {
    setDispatchedMap((prev) => ({ ...prev, [riskId]: true }));
    onDispatchAction(riskId);
  };

  const getRiskIcon = (title: string) => {
    if (title.toLowerCase().includes('rain') || title.toLowerCase().includes('flood')) {
      return <CloudRain className="w-5 h-5 text-sky-600" />;
    }
    if (title.toLowerCase().includes('power') || title.toLowerCase().includes('transformer')) {
      return <Zap className="w-5 h-5 text-amber-600" />;
    }
    return <Droplets className="w-5 h-5 text-blue-600" />;
  };

  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 border border-purple-900/50 shadow-xl">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-400/30 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Proactive Civic Intelligence</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            AI Predictive Governance & Preventive Actions
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            By fusing real-time weather meteorological forecasts, past complaint velocity, and equipment wear indicators, the AI anticipates civic emergencies before citizens face disruptions.
          </p>
        </div>
      </div>

      {/* Grid of Predictive Risks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {predictiveRisks.map((risk) => {
          const isDispatched = dispatchedMap[risk.id];

          return (
            <div
              key={risk.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center shrink-0">
                      {getRiskIcon(risk.title)}
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        Forecast Horizon: {risk.timeline}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 leading-snug">
                        {risk.title}
                      </h3>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold uppercase shrink-0 ${
                      risk.riskLevel === 'Critical'
                        ? 'bg-red-100 text-red-700 border border-red-200'
                        : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {risk.riskLevel} Risk ({risk.probability}%)
                  </span>
                </div>

                {/* Location & Dept */}
                <div className="flex items-center justify-between text-xs text-slate-600 mb-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="flex items-center gap-1.5 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    {risk.location}
                  </span>
                  <span className="font-bold text-blue-700">{risk.department}</span>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-700 leading-relaxed mb-4">
                  {risk.description}
                </p>

                {/* Recommended Preventive Action Box */}
                <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80 text-amber-950 mb-4">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 block mb-1">
                    🛡️ AI Recommended Preventive Action:
                  </span>
                  <p className="text-xs font-semibold leading-relaxed">
                    "{risk.recommendedPreventiveAction}"
                  </p>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Pre-emptive dispatch avoids citizen distress
                </span>

                {isDispatched ? (
                  <span className="px-4 py-2 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Work Order Dispatched</span>
                  </span>
                ) : (
                  <button
                    onClick={() => handleDispatch(risk.id)}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-transform hover:scale-102"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Dispatch Preventive Crew</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
