import React, { useState, useEffect } from 'react';
import { UserRole, Language, Complaint, Hotspot, PredictiveRisk, NotificationItem, AuthenticatedUser } from './types';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { NotificationModal } from './components/NotificationModal';
import { ExportModal } from './components/ExportModal';
import { AuthModal } from './components/AuthModal';

import { HomePage } from './pages/HomePage';
import { SubmitComplaintPage } from './pages/SubmitComplaintPage';
import { TrackComplaintPage } from './pages/TrackComplaintPage';
import { OfficerDashboardPage } from './pages/OfficerDashboardPage';
import { CollectorDashboardPage } from './pages/CollectorDashboardPage';
import { DepartmentViewPage } from './pages/DepartmentViewPage';
import { DistrictAnalyticsPage } from './pages/DistrictAnalyticsPage';
import { ProblemMap } from './components/ProblemMap';
import { PredictiveGovernancePage } from './pages/PredictiveGovernancePage';

import {
  INITIAL_COMPLAINTS,
  INITIAL_HOTSPOTS,
  INITIAL_PREDICTIVE_RISKS,
  INITIAL_NOTIFICATIONS,
} from './data/mockData';

export default function App() {
  // Global application states
  const [role, setRole] = useState<UserRole>('citizen');
  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(null);
  const [language, setLanguage] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [trackingComplaintId, setTrackingComplaintId] = useState<string>('IND-GRV-2026-10234');

  // Core data states
  const [complaints, setComplaints] = useState<Complaint[]>(INITIAL_COMPLAINTS);
  const [hotspots, setHotspots] = useState<Hotspot[]>(INITIAL_HOTSPOTS);
  const [predictiveRisks, setPredictiveRisks] = useState<PredictiveRisk[]>(INITIAL_PREDICTIVE_RISKS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Modals state
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Sync with backend API on mount
  useEffect(() => {
    async function loadData() {
      try {
        const [complaintsRes, hotspotsRes, risksRes, notifsRes] = await Promise.allSettled([
          fetch('/api/complaints'),
          fetch('/api/hotspots'),
          fetch('/api/predictive-risks'),
          fetch('/api/notifications'),
        ]);

        if (complaintsRes.status === 'fulfilled' && complaintsRes.value.ok) {
          const data = await complaintsRes.value.json();
          if (Array.isArray(data) && data.length > 0) setComplaints(data);
        }
        if (hotspotsRes.status === 'fulfilled' && hotspotsRes.value.ok) {
          const data = await hotspotsRes.value.json();
          if (Array.isArray(data) && data.length > 0) setHotspots(data);
        }
        if (risksRes.status === 'fulfilled' && risksRes.value.ok) {
          const data = await risksRes.value.json();
          if (Array.isArray(data) && data.length > 0) setPredictiveRisks(data);
        }
        if (notifsRes.status === 'fulfilled' && notifsRes.value.ok) {
          const data = await notifsRes.value.json();
          if (Array.isArray(data) && data.length > 0) setNotifications(data);
        }
      } catch (err) {
        console.warn('API data fetch failed, using local resilient dataset:', err);
      }
    }
    loadData();
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Handlers
  const handleComplaintSubmitted = (newComplaint: Complaint) => {
    setComplaints((prev) => [newComplaint, ...prev]);

    // Dispatch a simulated SMS & In-app notification
    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      complaintId: newComplaint.id,
      title: 'Grievance Acknowledged & Auto-Routed',
      message: `Namaste ${newComplaint.citizen.name}, your grievance ${newComplaint.id} was decomposed into ${newComplaint.issuesDetected.length} department tasks with Citizen Charter SLAs. Track live status anytime.`,
      channel: 'sms',
      recipientRole: 'citizen',
      timestamp: new Date().toISOString(),
      read: false,
      type: 'new_assignment',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const handleUpdateIssueStatus = async (complaintId: string, issueId: string, newStatus: string) => {
    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        const updatedIssues = c.issuesDetected.map((i) =>
          i.id === issueId ? { ...i, status: newStatus as any } : i
        );

        // Calculate overall status
        const allResolved = updatedIssues.every((i) => i.status === 'Resolved' || i.status === 'Closed');
        const anyInProgress = updatedIssues.some((i) => i.status === 'In Progress');
        let nextOverall = c.overallStatus;
        if (allResolved) nextOverall = 'Resolved';
        else if (anyInProgress) nextOverall = 'In Progress';

        return {
          ...c,
          issuesDetected: updatedIssues,
          overallStatus: nextOverall,
        };
      })
    );

    // Call server to persist
    try {
      await fetch(`/api/complaints/${complaintId}/issues/${issueId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
    } catch {
      // ignore
    }

    // Add in-app notification
    const statusNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      complaintId,
      title: `Status Updated: ${newStatus}`,
      message: `Work Order ${issueId} on ${complaintId} updated to "${newStatus}" by assigned field squad.`,
      channel: 'in-app',
      recipientRole: 'officer',
      timestamp: new Date().toISOString(),
      read: false,
      type: 'status_update',
    };
    setNotifications((prev) => [statusNotif, ...prev]);
  };

  const handleTriggerSimulatedNotification = (channel: 'sms' | 'whatsapp' | 'email') => {
    const channelNames = {
      sms: 'SMS Alert to Citizen Mobile',
      whatsapp: 'WhatsApp Alert to Citizen Mobile',
      email: 'Email Digest to citizen@domain.in',
    };

    const simNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      complaintId: 'IND-GRV-2026-10234',
      title: `[Simulated] ${channelNames[channel]}`,
      message: `Dear Citizen, Field Engineer has initiated repair on Work Order #01. Scheduled completion is today within Citizen Charter SLA.`,
      channel,
      recipientRole: 'citizen',
      timestamp: new Date().toISOString(),
      read: false,
      type: 'status_update',
    };

    setNotifications((prev) => [simNotif, ...prev]);
  };

  const handleMarkNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleFeedbackSubmit = async (feedbackData: any) => {
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(feedbackData),
      });
    } catch {
      // local
    }

    const feedbackNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      complaintId: feedbackData.complaintId,
      title: 'Citizen Feedback Received',
      message: `${feedbackData.citizenName} rated ${feedbackData.department} ${feedbackData.rating}/5 stars.`,
      channel: 'in-app',
      recipientRole: 'collector',
      timestamp: new Date().toISOString(),
      read: false,
      type: 'status_update',
    };
    setNotifications((prev) => [feedbackNotif, ...prev]);
  };

  const handleNavigateToTrack = (complaintId: string) => {
    setTrackingComplaintId(complaintId);
    setActiveTab('track');
  };

  const handleLoadDemo = () => {
    setTrackingComplaintId('IND-GRV-2026-10234');
    setActiveTab('track');
  };

  const handleAuthSuccess = (user: AuthenticatedUser) => {
    setCurrentUser(user);
    setRole(user.role);
    if (user.role === 'collector') {
      setActiveTab('collector');
    } else if (user.role === 'officer') {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setRole('citizen');
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Universal Header with National Branding & Auth Modal trigger */}
      <Header
        currentRole={role}
        currentUser={currentUser}
        onRoleChange={setRole}
        onSignOut={handleLogout}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        unreadCount={unreadCount}
        onOpenNotifications={() => setIsNotificationModalOpen(true)}
      />

      {/* Navigation Tab Bar with National Tabs */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        pendingCount={complaints.filter((c) => c.overallStatus === 'Pending' || c.overallStatus === 'Routed').length}
        currentRole={role}
      />

      {/* Main Page Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        {activeTab === 'home' && (
          <HomePage onNavigate={setActiveTab} />
        )}

        {activeTab === 'submit' && (
          <SubmitComplaintPage
            onComplaintSubmitted={handleComplaintSubmitted}
            onNavigateTrack={handleNavigateToTrack}
          />
        )}

        {activeTab === 'track' && (
          <TrackComplaintPage
            complaints={complaints}
            initialComplaintId={trackingComplaintId}
            userRole={role}
            onUpdateIssueStatus={handleUpdateIssueStatus}
            onSubmitFeedback={handleFeedbackSubmit}
          />
        )}

        {activeTab === 'dashboard' && (
          <OfficerDashboardPage
            complaints={complaints}
            userRole={role}
            currentUser={currentUser}
            onUpdateIssueStatus={handleUpdateIssueStatus}
            onSelectComplaintForTracking={handleNavigateToTrack}
            onOpenExportModal={() => setIsExportModalOpen(true)}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'collector' && (
          <CollectorDashboardPage
            complaints={complaints}
            hotspots={hotspots}
            predictiveRisks={predictiveRisks}
            currentUser={currentUser}
            onSelectComplaintForTracking={handleNavigateToTrack}
            onOpenExportModal={() => setIsExportModalOpen(true)}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'departments' && (
          <DepartmentViewPage
            complaints={complaints}
            userRole={role}
            onUpdateIssueStatus={handleUpdateIssueStatus}
          />
        )}

        {activeTab === 'analytics' && (
          <DistrictAnalyticsPage complaints={complaints} />
        )}

        {activeTab === 'map' && (
          <div className="space-y-4">
            <ProblemMap
              complaints={complaints}
              hotspots={hotspots}
              onSelectComplaint={handleNavigateToTrack}
            />
          </div>
        )}

        {activeTab === 'predictive' && (
          <PredictiveGovernancePage
            predictiveRisks={predictiveRisks}
            onDispatchAction={(riskId) => {
              const risk = predictiveRisks.find((r) => r.id === riskId);
              const dispatchNotif: NotificationItem = {
                id: `NOTIF-${Date.now()}`,
                complaintId: 'PREVENTIVE-WO-2026',
                title: `Pre-emptive Work Order Issued: ${risk?.title}`,
                message: `Maintenance squad dispatched to ${risk?.location} under ${risk?.department}.`,
                channel: 'sms',
                recipientRole: 'officer',
                timestamp: new Date().toISOString(),
                read: false,
                type: 'critical_alert',
              };
              setNotifications((prev) => [dispatchNotif, ...prev]);
            }}
          />
        )}
      </main>

      {/* Official Government Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-8 px-4 text-xs mt-auto">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-slate-200 font-bold">
              <span>भारत सरकार • Government of India</span>
              <span className="text-slate-600">|</span>
              <span className="text-blue-400 font-mono text-[11px]">CIVIC PRAXIS National Smart Governance Engine</span>
            </div>
            <p className="text-slate-500 text-[11px]">
              AI-Powered Multilingual Grievance Decomposition, Parallel Department Dispatch & Citizen Charter SLA Monitoring.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">
              National Citizen Helpline: <strong className="text-white">1915</strong>
            </span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">
              Emergency Response: <strong className="text-white">112</strong>
            </span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">
              Disaster Helpline: <strong className="text-white">1077</strong>
            </span>
            <span className="text-slate-500">
              Security: Free Citizen Access • Zero Password Barrier • Role-Based Officer RBAC
            </span>
          </div>
        </div>
      </footer>

      {/* Multi-Channel Notification Modal */}
      <NotificationModal
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        notifications={notifications}
        currentRole={role}
        onMarkRead={handleMarkNotificationRead}
        onTriggerSimulatedNotification={handleTriggerSimulatedNotification}
      />

      {/* CSV and PDF Export Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        complaints={complaints}
      />

      {/* Official Government Login Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleAuthSuccess}
        onAuthSuccess={handleAuthSuccess}
      />
    </div>
  );
}
