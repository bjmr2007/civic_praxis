import React from 'react';
import {
  Home,
  FileText,
  Search,
  LayoutDashboard,
  Building2,
  BarChart3,
  MapPin,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { UserRole } from '../types';
import { useLanguage } from '../context/LanguageContext';

export type NavTab =
  | 'home'
  | 'submit'
  | 'track'
  | 'dashboard'
  | 'collector'
  | 'departments'
  | 'analytics'
  | 'map'
  | 'predictive';

interface NavigationProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  pendingCount?: number;
  currentRole: UserRole;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  pendingCount = 0,
  currentRole,
}) => {
  const { t } = useLanguage();

  const tabs: {
    id: NavTab;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: number;
    highlight?: boolean;
  }[] = [
    { id: 'home', label: t.navHome, icon: Home },
    { id: 'submit', label: t.navSubmit, icon: FileText, highlight: true },
    { id: 'track', label: t.navTrack, icon: Search },
    {
      id: 'dashboard',
      label: currentRole === 'officer' ? `${t.navOfficer}` : t.navOfficer,
      icon: LayoutDashboard,
      badge: pendingCount > 0 ? pendingCount : undefined,
    },
    {
      id: 'collector',
      label: t.navCollector,
      icon: ShieldAlert,
    },
    { id: 'departments', label: t.navDepartments, icon: Building2 },
    { id: 'analytics', label: t.navAnalytics, icon: BarChart3 },
    { id: 'map', label: t.navMap, icon: MapPin },
    { id: 'predictive', label: t.navPredictive, icon: Sparkles },
  ];

  return (
    <nav className="bg-slate-900 text-slate-300 border-b border-slate-800 shadow-sm overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-1 sm:space-x-1.5 py-2 min-w-max">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                id={`nav-tab-${tab.id}`}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm ring-1 ring-blue-400/40'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${
                      isActive ? 'bg-white text-blue-700' : 'bg-blue-500/30 text-blue-300'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
