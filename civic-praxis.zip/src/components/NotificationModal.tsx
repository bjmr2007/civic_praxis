import React, { useState } from 'react';
import { NotificationItem, UserRole } from '../types';
import {
  Bell,
  MessageSquare,
  Smartphone,
  Mail,
  Send,
  X,
  Check,
  CheckCheck,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  currentRole: UserRole;
  onMarkRead: (id: string) => void;
  onTriggerSimulatedNotification: (channel: 'sms' | 'whatsapp' | 'email') => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications,
  currentRole,
  onMarkRead,
  onTriggerSimulatedNotification,
}) => {
  const [activeChannel, setActiveChannel] = useState<'all' | 'in-app' | 'sms' | 'whatsapp' | 'email'>('all');

  if (!isOpen) return null;

  const filtered = notifications.filter((n) => {
    if (activeChannel !== 'all' && n.channel !== activeChannel) return false;
    return true;
  });

  const getChannelIcon = (ch: string) => {
    switch (ch) {
      case 'sms':
        return <Smartphone className="w-4 h-4 text-emerald-600" />;
      case 'whatsapp':
        return <MessageSquare className="w-4 h-4 text-green-600" />;
      case 'email':
        return <Mail className="w-4 h-4 text-blue-600" />;
      case 'in-app':
      default:
        return <Bell className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Official Notification Center
              </h3>
              <p className="text-xs text-slate-500">
                Real-time citizen SMS, WhatsApp alerts, in-app dispatch & official notices
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Channel Filter Tabs */}
        <div className="px-4 py-2 border-b border-slate-200 bg-white flex flex-wrap items-center justify-between gap-2">
          <div className="flex space-x-1">
            {[
              { id: 'all', label: 'All Channels' },
              { id: 'in-app', label: 'In-App' },
              { id: 'sms', label: '💬 SMS' },
              { id: 'whatsapp', label: '📱 WhatsApp' },
              { id: 'email', label: '✉️ Email' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveChannel(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  activeChannel === tab.id
                    ? 'bg-blue-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <Bell className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-medium">No notifications in this channel.</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  item.read
                    ? 'bg-slate-50/70 border-slate-200 opacity-80'
                    : 'bg-white border-blue-200 shadow-xs ring-1 ring-blue-100'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <div className="mt-0.5 p-1.5 rounded-lg bg-slate-100 border border-slate-200">
                      {getChannelIcon(item.channel)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{item.title}</span>
                        <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                          {item.channel}
                        </span>
                        <span className="text-[10px] text-blue-600 font-mono font-medium">
                          {item.complaintId}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                        {item.message}
                      </p>
                      <div className="mt-2 flex items-center gap-3 text-[10px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(item.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        <span>Recipient: {item.recipientRole}</span>
                      </div>
                    </div>
                  </div>

                  {!item.read && (
                    <button
                      onClick={() => onMarkRead(item.id)}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium px-2 py-1 rounded hover:bg-blue-50 cursor-pointer shrink-0"
                      title="Mark as read"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 text-center text-xs text-slate-500 flex items-center justify-between px-5">
          <span>Simulation Active: Citizen phone numbers are masked (98765XXXXX).</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
