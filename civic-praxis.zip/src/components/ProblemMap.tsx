import React, { useState } from 'react';
import { Complaint, Hotspot, Priority } from '../types';
import {
  MapPin,
  AlertTriangle,
  Flame,
  CheckCircle2,
  Clock,
  Layers,
  Filter,
  X,
  ExternalLink,
  Shield,
  Eye,
} from 'lucide-react';

interface ProblemMapProps {
  complaints: Complaint[];
  hotspots: Hotspot[];
  onSelectComplaint?: (complaintId: string) => void;
}

export const ProblemMap: React.FC<ProblemMapProps> = ({
  complaints,
  hotspots,
  onSelectComplaint,
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [activeMarker, setActiveMarker] = useState<Complaint | null>(null);
  const [activeHotspot, setActiveHotspot] = useState<Hotspot | null>(null);
  const [showHotspotRings, setShowHotspotRings] = useState<boolean>(true);

  // Filter complaints based on district
  const filteredComplaints = selectedDistrict === 'All'
    ? complaints
    : complaints.filter((c) => c.location.district.toLowerCase() === selectedDistrict.toLowerCase());

  // Districts for filter
  const districts = ['All', 'Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem'];

  // Map latitude/longitude bounds for Tamil Nadu visual coordinate scaling
  // Approx TN bounds: Lat 8.0 - 13.5 N, Lng 76.2 - 80.4 E
  const scaleCoordinates = (lat: number, lng: number) => {
    // Normalizing between 0% and 100% within our SVG container
    const minLat = 8.2;
    const maxLat = 13.5;
    const minLng = 76.2;
    const maxLng = 80.5;

    // Invert lat for SVG Y axis (higher lat = higher up = lower Y)
    const y = ((maxLat - lat) / (maxLat - minLat)) * 82 + 9;
    const x = ((lng - minLng) / (maxLng - minLng)) * 82 + 9;

    return { x: Math.max(5, Math.min(95, x)), y: Math.max(5, Math.min(95, y)) };
  };

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case 'Critical':
        return {
          bg: 'bg-red-600',
          ring: 'ring-red-400',
          pulse: 'bg-red-400',
          border: 'border-red-600',
          label: '🔴 Critical',
        };
      case 'High':
        return {
          bg: 'bg-amber-500',
          ring: 'ring-amber-300',
          pulse: 'bg-amber-300',
          border: 'border-amber-500',
          label: '🟠 High',
        };
      case 'Medium':
        return {
          bg: 'bg-blue-600',
          ring: 'ring-blue-300',
          pulse: 'bg-blue-300',
          border: 'border-blue-600',
          label: '🟡 Medium',
        };
      case 'Low':
      default:
        return {
          bg: 'bg-emerald-600',
          ring: 'ring-emerald-300',
          pulse: 'bg-emerald-300',
          border: 'border-emerald-600',
          label: '🟢 Low',
        };
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Map Control Bar */}
      <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Interactive Smart Problem Map of Tamil Nadu
            </h3>
            <p className="text-xs text-slate-500">
              Real-time spatial incident clustering, priority markers & systemic infrastructure hotspots
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* District filter */}
          <div className="flex items-center gap-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-600 font-medium">District:</span>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
            >
              {districts.map((d) => (
                <option key={d} value={d}>
                  {d === 'All' ? 'All Districts' : d}
                </option>
              ))}
            </select>
          </div>

          {/* Hotspots toggle */}
          <label className="flex items-center gap-1.5 text-xs text-slate-700 font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={showHotspotRings}
              onChange={(e) => setShowHotspotRings(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <span>Show Hotspots</span>
          </label>
        </div>
      </div>

      {/* Map Canvas Area */}
      <div className="relative w-full h-[520px] bg-slate-950 overflow-hidden select-none">
        {/* Stylized Tamil Nadu Grid & Geography Backdrop */}
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full object-cover opacity-90"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            <pattern id="grid" width="5" height="5" patternUnits="userSpaceOnUse">
              <path d="M 5 0 L 0 0 0 5" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="0.2" />
            </pattern>
            <radialGradient id="hotspotGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(239, 68, 68, 0.4)" />
              <stop offset="100%" stopColor="rgba(239, 68, 68, 0)" />
            </radialGradient>
          </defs>

          {/* Dark map grid */}
          <rect width="100" height="100" fill="#090d16" />
          <rect width="100" height="100" fill="url(#grid)" />

          {/* Stylized Tamil Nadu State Boundary Polygon */}
          <path
            d="M 88,14 
               C 89,16 85,25 84,33 
               C 83,42 86,52 82,60 
               C 78,68 76,76 74,84 
               C 70,89 64,95 58,96 
               C 52,94 48,88 46,82 
               C 44,74 41,66 38,58 
               C 36,50 32,45 34,36 
               C 36,28 42,20 50,16 
               C 62,12 76,11 88,14 Z"
            fill="#0f172a"
            stroke="#1e3a8a"
            strokeWidth="0.7"
            strokeDasharray="1.5, 1"
          />

          {/* Regional Coastal Highlight */}
          <path
            d="M 88,14 C 89,16 85,25 84,33 C 83,42 86,52 82,60 C 78,68 76,76 74,84"
            fill="none"
            stroke="#38bdf8"
            strokeWidth="0.9"
            strokeOpacity="0.4"
          />

          {/* Major District Landmarks */}
          <g className="text-[2.6px] font-sans font-bold fill-slate-500 tracking-wider">
            <text x="81" y="20">CHENNAI</text>
            <text x="35" y="44">COIMBATORE</text>
            <text x="56" y="58">MADURAI</text>
            <text x="60" y="42">TIRUCHY</text>
            <text x="52" y="32">SALEM</text>
            <text x="50" y="82">TIRUNELVELI</text>
          </g>
        </svg>

        {/* Hotspot Halos */}
        {showHotspotRings &&
          hotspots.map((h) => {
            const pos = scaleCoordinates(h.coordinates.lat, h.coordinates.lng);
            return (
              <div
                key={h.id}
                style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                onClick={() => {
                  setActiveHotspot(h);
                  setActiveMarker(null);
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 group"
              >
                <div className="w-16 h-16 rounded-full bg-red-500/20 border-2 border-red-500/40 animate-ping" />
                <div className="absolute inset-0 w-16 h-16 rounded-full bg-red-600/10 border border-red-400/50 flex items-center justify-center -translate-x-0 -translate-y-0">
                  <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[9px] font-black shadow-md">
                    {h.complaintCount}
                  </span>
                </div>
              </div>
            );
          })}

        {/* Priority Markers for Complaints */}
        {filteredComplaints.map((c) => {
          const pos = scaleCoordinates(c.location.latitude, c.location.longitude);
          const style = getPriorityColor(c.overallPriority);
          const isSelected = activeMarker?.id === c.id;

          return (
            <div
              key={c.id}
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
              onClick={() => {
                setActiveMarker(c);
                setActiveHotspot(null);
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20 group"
            >
              {/* Pulse effect for Critical/High */}
              {(c.overallPriority === 'Critical' || c.overallPriority === 'High') && (
                <span className={`absolute -inset-1 rounded-full ${style.pulse} opacity-75 animate-ping`} />
              )}

              {/* Marker pin */}
              <div
                className={`relative w-6 h-6 rounded-full ${style.bg} text-white flex items-center justify-center shadow-lg ring-2 ${
                  isSelected ? 'ring-white scale-125 z-30' : 'ring-slate-900/60'
                } transition-transform hover:scale-125`}
              >
                <span className="text-[10px] font-black">
                  {c.overallPriority === 'Critical' ? '!' : c.issuesDetected.length}
                </span>
              </div>

              {/* Tooltip on hover */}
              <div className="absolute left-1/2 bottom-full mb-1.5 -translate-x-1/2 hidden group-hover:block z-30 bg-slate-900 text-white text-[11px] px-2.5 py-1 rounded shadow-lg whitespace-nowrap border border-slate-700">
                <span className="font-bold">{c.location.area}</span>: {c.issuesDetected[0]?.issueSummary.slice(0, 24)}...
              </div>
            </div>
          );
        })}

        {/* Map Legend */}
        <div className="absolute bottom-4 left-4 z-20 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 text-xs text-white shadow-lg space-y-1.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Priority Markers
          </span>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-600 ring-2 ring-red-400" />
            <span className="text-slate-300">🔴 Critical (&lt; 24h SLA)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500 ring-2 ring-amber-300" />
            <span className="text-slate-300">🟠 High (48h SLA)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-600 ring-2 ring-blue-300" />
            <span className="text-slate-300">🟡 Medium (3-7 Days)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-600 ring-2 ring-emerald-300" />
            <span className="text-slate-300">🟢 Low (14 Days)</span>
          </div>
        </div>

        {/* Selected Complaint Flyout Card (Section 12 requirement) */}
        {activeMarker && (
          <div className="absolute top-4 right-4 z-30 w-84 bg-white rounded-xl shadow-2xl border border-slate-200 p-4 animate-in fade-in slide-in-from-right duration-200">
            <div className="flex items-start justify-between gap-2 mb-2 pb-2 border-b border-slate-100">
              <div>
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">
                  Complaint Details
                </span>
                <h4 className="text-xs font-mono font-bold text-slate-900">
                  {activeMarker.id}
                </h4>
              </div>
              <button
                onClick={() => setActiveMarker(null)}
                className="text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Location:</span>
                <span className="font-semibold text-slate-800">
                  📍 {activeMarker.location.area}, {activeMarker.location.district}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Primary Department:</span>
                <span className="font-semibold text-blue-700">
                  {activeMarker.issuesDetected[0]?.department}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Priority:</span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    activeMarker.overallPriority === 'Critical'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {activeMarker.overallPriority}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-800">
                  {activeMarker.overallStatus}
                </span>
              </div>

              {/* Sub-issues breakdown */}
              <div className="pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Split Sub-Issues ({activeMarker.issuesDetected.length})
                </span>
                <div className="space-y-1">
                  {activeMarker.issuesDetected.map((issue) => (
                    <div
                      key={issue.id}
                      className="p-1.5 rounded bg-slate-50 border border-slate-100 text-[11px]"
                    >
                      <div className="font-semibold text-slate-800">{issue.issueSummary}</div>
                      <div className="text-[10px] text-slate-500 flex justify-between mt-0.5">
                        <span>{issue.department}</span>
                        <span className="font-bold text-amber-700">SLA: {issue.deadline}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {onSelectComplaint && (
                <button
                  onClick={() => onSelectComplaint(activeMarker.id)}
                  className="w-full mt-2 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Open Full Tracker</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Selected Hotspot Flyout Card (Section 13 requirement) */}
        {activeHotspot && (
          <div className="absolute top-4 right-4 z-30 w-88 bg-white rounded-xl shadow-2xl border-2 border-red-500 p-4 animate-in fade-in slide-in-from-right duration-200">
            <div className="flex items-start justify-between gap-2 mb-2 pb-2 border-b border-red-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-red-100 text-red-600 flex items-center justify-center font-bold">
                  🚨
                </div>
                <div>
                  <h4 className="text-xs font-black text-red-700 tracking-tight">
                    PROBLEM HOTSPOT DETECTED
                  </h4>
                  <span className="text-[11px] font-semibold text-slate-700">
                    {activeHotspot.locationName}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveHotspot(null)}
                className="text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between bg-red-50 p-2 rounded-lg border border-red-100">
                <span className="text-red-900 font-medium">Similar Complaints:</span>
                <span className="font-black text-red-700 text-sm">
                  {activeHotspot.complaintCount} Incidents
                </span>
              </div>

              <div>
                <span className="text-slate-500 font-medium block">Issue Cluster:</span>
                <span className="font-bold text-slate-800">{activeHotspot.issueType}</span>
              </div>

              <div>
                <span className="text-slate-500 font-medium block">Department in Charge:</span>
                <span className="font-bold text-blue-700">{activeHotspot.department}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900">
                <span className="font-bold block text-[11px] uppercase tracking-wider mb-1">
                  AI Recommended Action:
                </span>
                <p className="text-[11px] leading-relaxed font-medium">
                  "{activeHotspot.recommendedAction}"
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
