import React, { useState } from 'react';
import { Complaint } from '../types';
import { INDIAN_STATES } from '../data/indiaLocations';
import {
  BarChart3,
  TrendingUp,
  Award,
  Zap,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Calendar,
  Filter,
} from 'lucide-react';

interface DistrictAnalyticsPageProps {
  complaints: Complaint[];
}

export const DistrictAnalyticsPage: React.FC<DistrictAnalyticsPageProps> = ({
  complaints,
}) => {
  const [selectedState, setSelectedState] = useState<string>('All');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');

  // Categories breakdown
  const categoryStats = [
    { category: 'Municipal Corporation & Sanitation', count: 1420, percentage: 32, color: 'bg-emerald-500' },
    { category: 'Electricity & DISCOM', count: 1180, percentage: 26, color: 'bg-amber-500' },
    { category: 'Water Supply & Sewerage', count: 990, percentage: 22, color: 'bg-sky-500' },
    { category: 'Roads & Infrastructure (PWD)', count: 540, percentage: 12, color: 'bg-orange-500' },
    { category: 'Public Health & Police Support', count: 360, percentage: 8, color: 'bg-rose-500' },
  ];

  // Department League Table
  const departmentPerformance = [
    { name: 'Water Supply & Sewerage Board', assigned: 990, resolved: 968, sla: 97.8, avgDays: 1.4 },
    { name: 'Municipal Corporation / Sanitation', assigned: 1420, resolved: 1370, sla: 96.5, avgDays: 1.8 },
    { name: 'State Power Distribution (DISCOM)', assigned: 1180, resolved: 1125, sla: 95.3, avgDays: 2.1 },
    { name: 'Public Health Department', assigned: 360, resolved: 348, sla: 96.7, avgDays: 1.5 },
    { name: 'Public Works Department (PWD)', assigned: 540, resolved: 492, sla: 91.1, avgDays: 3.8 },
    { name: 'Police & Traffic Enforcement', assigned: 280, resolved: 275, sla: 98.2, avgDays: 0.9 },
  ];

  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 text-blue-700">
              <BarChart3 className="w-5 h-5" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              National Grievance Analytics & Governance Performance
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Macro-level civic redressal metrics, department SLA league tables, and AI operational throughput across India.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-slate-600 font-medium">Filter State:</span>
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none"
          >
            <option value="All">All India (36 States & UTs)</option>
            {INDIAN_STATES.slice(0, 10).map((s) => (
              <option key={s.stateCode} value={s.stateName}>
                {s.stateName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* High-Level AI & Administrative KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white p-5 rounded-2xl shadow-sm border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-300 font-bold uppercase tracking-wider">
              AI Routing Precision
            </span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black mt-2">98.2%</div>
          <span className="text-[11px] text-blue-300 mt-1 block">
            Over 52,400 multi-issue tickets
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">
              Avg Dispatch Speed
            </span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-black text-slate-900 mt-2">&lt; 1.8s</div>
          <span className="text-[11px] text-emerald-600 font-bold mt-1 block">
            Real-time parallel routing
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">
              Citizen Charter SLA
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black text-emerald-600 mt-2">96.8%</div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Resolved within statutory window
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">
              Multi-Issue Ratio
            </span>
            <Award className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-3xl font-black text-indigo-600 mt-2">74.6%</div>
          <span className="text-[11px] text-indigo-500 mt-1 block">
            Petitions containing 2+ distinct problems
          </span>
        </div>
      </div>

      {/* Grid: Category Breakdown + SLA League Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Breakdown (1 col) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
            Issue Category Distribution
          </h3>
          <p className="text-xs text-slate-500">
            Proportion of grievances decomposed across core civic sectors.
          </p>

          <div className="space-y-3 pt-2">
            {categoryStats.map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-700">{item.category}</span>
                  <span className="text-slate-900 font-mono font-bold">
                    {item.percentage}% ({item.count})
                  </span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} rounded-full`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Department SLA League Table (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                Department Citizen Charter SLA Leaderboard
              </h3>
              <p className="text-xs text-slate-500">
                Ranked by on-time resolution rate and average turnaround time.
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-600">Updated Live</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="pb-3">Department Agency</th>
                  <th className="pb-3 text-center">Assigned</th>
                  <th className="pb-3 text-center">Resolved</th>
                  <th className="pb-3 text-center">SLA Compliance</th>
                  <th className="pb-3 text-right">Avg Resolution</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {departmentPerformance.map((dept, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 font-bold text-slate-800 flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-mono text-[10px]">
                        {idx + 1}
                      </span>
                      <span>{dept.name}</span>
                    </td>
                    <td className="py-3 text-center font-mono font-semibold text-slate-600">
                      {dept.assigned}
                    </td>
                    <td className="py-3 text-center font-mono font-semibold text-slate-800">
                      {dept.resolved}
                    </td>
                    <td className="py-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full font-mono font-bold text-[11px] ${
                          dept.sla >= 95
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-amber-50 text-amber-700'
                        }`}
                      >
                        {dept.sla}%
                      </span>
                    </td>
                    <td className="py-3 text-right font-mono font-bold text-slate-700">
                      {dept.avgDays} Days
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
