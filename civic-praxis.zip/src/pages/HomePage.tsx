import React from 'react';
import { NavTab } from '../components/Navigation';
import { RoutingVisualization } from '../components/RoutingVisualization';
import { useLanguage } from '../context/LanguageContext';
import {
  Sparkles,
  ArrowRight,
  Zap,
  Clock,
  Split,
  MapPin,
  Flame,
  CheckCircle2,
  XCircle,
  Building2,
  FileText,
  Search,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (tab: NavTab) => void;
  onLoadDemo?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { t } = useLanguage();

  return (
    <div className="space-y-12 py-6">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white p-8 sm:p-12 border border-slate-800 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 rounded-full bg-blue-600/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-96 h-96 rounded-full bg-emerald-600/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30 mb-5">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>CIVIC PRAXIS • {t.nationalHeader}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight">
            {t.heroTagline}
          </h1>

          <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl font-normal">
            {t.heroDesc}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('submit')}
              id="btn-hero-submit"
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer hover:translate-y-[-1px]"
            >
              <FileText className="w-4 h-4" />
              <span>{t.submitGrievance}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('track')}
              id="btn-hero-track"
              className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
            >
              <Search className="w-4 h-4 text-blue-400" />
              <span>{t.trackGrievance}</span>
            </button>

            <button
              onClick={() => onNavigate('map')}
              id="btn-hero-map"
              className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 border border-white/20 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer backdrop-blur-xs"
            >
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>{t.navMap}</span>
            </button>
          </div>

          {/* Key quick indicators */}
          <div className="mt-10 pt-8 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div>
              <span className="text-slate-400 block">Pan-India Coverage</span>
              <strong className="text-slate-100 text-sm">36 States & UTs</strong>
            </div>
            <div>
              <span className="text-slate-400 block">Indian Languages</span>
              <strong className="text-slate-100 text-sm">Hindi, Tamil, Telugu, & All</strong>
            </div>
            <div>
              <span className="text-slate-400 block">Average Dispatch Time</span>
              <strong className="text-emerald-400 text-sm">&lt; 1.8 Seconds</strong>
            </div>
            <div>
              <span className="text-slate-400 block">Citizen SLA Adherence</span>
              <strong className="text-blue-400 text-sm">96.8% On-Time</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div>
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Core Capabilities of CIVIC PRAXIS
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            Engineered to replace manual bureaucratic triaging with precision natural language decomposition, parallel routing, and predictive civic foresight.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              icon: Split,
              title: 'AI Multi-Issue Decomposition',
              desc: 'Splits compound complaints with multiple problems into distinct, actionable sub-issues without losing context.',
              color: 'text-blue-600 bg-blue-50 border-blue-200',
            },
            {
              icon: Building2,
              title: 'Parallel Department Routing',
              desc: 'Directs every sub-issue to PWD, Electricity, Water Supply, Municipal Corporation, Health, or Police with verified SLAs.',
              color: 'text-indigo-600 bg-indigo-50 border-indigo-200',
            },
            {
              icon: Clock,
              title: 'Citizen Charter SLAs',
              desc: 'Enforces statutory resolution deadlines (24h, 48h, 7d) with automatic escalation alerts before SLA breach.',
              color: 'text-amber-600 bg-amber-50 border-amber-200',
            },
            {
              icon: Flame,
              title: 'Hotspot & Predictive Governance',
              desc: 'Identifies recurring problem clusters across districts and forecasts seasonal risks (monsoon deluge, grid overload).',
              color: 'text-rose-600 bg-rose-50 border-rose-200',
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-all space-y-3"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.color} border`}>
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive AI Routing Visualization */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
              Live Architecture Visualization
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
              How a Single Citizen Grievance is Decomposed into Parallel Work Orders
            </h3>
          </div>
          <button
            onClick={() => onNavigate('submit')}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <span>File a Grievance</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <RoutingVisualization />
      </div>

      {/* Before vs After Comparison */}
      <div>
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Transforming Grievance Redressal Across India
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            Why automated multi-department routing is essential for modern citizen-centric administration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Legacy System */}
          <div className="p-6 rounded-3xl bg-rose-50/50 border border-rose-200 space-y-4">
            <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
              <XCircle className="w-5 h-5 text-rose-500" />
              <span>Legacy Manual Triaging System</span>
            </div>
            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span><strong>Single-Department Trap:</strong> Complaints mentioning multiple problems get assigned to only one department; remaining issues are ignored.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span><strong>Language Bottleneck:</strong> Complaints in regional languages take days to be manually translated and sorted.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span><strong>No Predictive Capacity:</strong> 50 repeated complaints about water pipelines in one colony are treated as 50 isolated tickets rather than an infrastructure alert.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span><strong>Opaque Status:</strong> Citizens wait weeks with zero updates or SMS notifications until their ticket is closed without explanation.</span>
              </li>
            </ul>
          </div>

          {/* CIVIC PRAXIS System */}
          <div className="p-6 rounded-3xl bg-emerald-50/60 border border-emerald-200 space-y-4">
            <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>CIVIC PRAXIS Smart AI Routing</span>
            </div>
            <ul className="space-y-3 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span><strong>Automatic Multi-Issue Decomposition:</strong> Each problem gets its own distinct work order with tailored deadlines, priority, and assigned field officers.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span><strong>Native Multilingual AI:</strong> Directly processes English, Hindi, Tamil, Telugu, Kannada, Bengali, Marathi and colloquial text in &lt; 2 seconds.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span><strong>Proactive Hotspots & Risk Radar:</strong> Machine learning clusters duplicate complaints to warn District Collectors before severe civic crises emerge.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span><strong>Full Transparency:</strong> Citizens get real-time SMS & WhatsApp updates at every stage with direct contact details for their assigned officer.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
