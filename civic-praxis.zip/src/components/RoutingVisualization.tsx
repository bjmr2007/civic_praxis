import React, { useState } from 'react';
import {
  FileText,
  Cpu,
  Split,
  Zap,
  Droplets,
  Trash2,
  Construction,
  HeartPulse,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

interface RoutingSample {
  id: string;
  name: string;
  originalText: string;
  detectedIssues: {
    title: string;
    department: string;
    icon: any;
    priority: string;
    deadline: string;
    officer: string;
    color: string;
  }[];
}

const PRELOADED_SAMPLES: RoutingSample[] = [
  {
    id: 'sample-1',
    name: 'Drainage + Streetlight + Stray Dogs (Sample 1)',
    originalText: 'Sir, near my house drainage water is not going, also there is no streetlight for 3 days and stray dogs are a big problem here.',
    detectedIssues: [
      {
        title: 'Drainage Blockage & Water Stagnation',
        department: 'Sanitation / Corporation',
        icon: Trash2,
        priority: 'High',
        deadline: '48 Hours',
        officer: 'M. Selvaraj (Executive Engineer)',
        color: 'emerald',
      },
      {
        title: 'Streetlight Not Working',
        department: 'TANGEDCO (Electricity Board)',
        icon: Zap,
        priority: 'Medium',
        deadline: '7 Days',
        officer: 'K. Parthiban (Asst Divisional Engineer)',
        color: 'amber',
      },
      {
        title: 'Stray Dog Threat & Vaccination',
        department: 'Health Department',
        icon: HeartPulse,
        priority: 'Medium',
        deadline: '3 Days',
        officer: 'Dr. S. Kanchana (Health Officer)',
        color: 'rose',
      },
    ],
  },
  {
    id: 'sample-2',
    name: 'Tamil: குடிநீர் + குப்பை (Sample 2)',
    originalText: 'எங்கள் பகுதியில் குடிநீர் சரியாக வரவில்லை. கடந்த இரண்டு நாட்களாக தெருவில் குப்பை தேங்கி உள்ளது.',
    detectedIssues: [
      {
        title: 'Drinking Water Supply Interruption',
        department: 'Water Board (Metro Water)',
        icon: Droplets,
        priority: 'High',
        deadline: '48 Hours',
        officer: 'V. Sundaram (Area Engineer)',
        color: 'blue',
      },
      {
        title: 'Solid Waste & Garbage Accumulation',
        department: 'Sanitation / Corporation',
        icon: Trash2,
        priority: 'Medium',
        deadline: '3 Days',
        officer: 'G. Mohan (Sanitary Inspector)',
        color: 'emerald',
      },
    ],
  },
  {
    id: 'sample-3',
    name: 'Road Damage + Water Leakage (Sample 3)',
    originalText: 'The road near the school is badly damaged and students are facing difficulty. Also there is water leakage.',
    detectedIssues: [
      {
        title: 'Severe Road Surface Potholes & Crater',
        department: 'Public Works Department (PWD)',
        icon: Construction,
        priority: 'Medium',
        deadline: '7 Days',
        officer: 'Er. R. Arumugam (AEE - PWD)',
        color: 'orange',
      },
      {
        title: 'Underground Drinking Water Pipe Rupture',
        department: 'Water Board (Metro Water)',
        icon: Droplets,
        priority: 'High',
        deadline: '48 Hours',
        officer: 'S. Jayaraman (Divisional Engineer)',
        color: 'blue',
      },
    ],
  },
];

export const RoutingVisualization: React.FC = () => {
  const [selectedSample, setSelectedSample] = useState<RoutingSample>(PRELOADED_SAMPLES[0]);

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-xl overflow-hidden">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400 border border-blue-400/30">
              <Split className="w-4 h-4" />
            </span>
            <h3 className="text-lg font-bold tracking-tight text-slate-100">
              Interactive AI Auto-Routing Flow Visualization
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Watch how a single multi-grievance statement is split into distinct issues and dispatched in parallel to multiple departments.
          </p>
        </div>

        {/* Sample selector buttons */}
        <div className="flex flex-wrap gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {PRELOADED_SAMPLES.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelectedSample(s)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedSample.id === s.id
                  ? 'bg-blue-600 text-white shadow-xs font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Flow Architecture */}
      <div className="pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
          {/* Step 1: Input Complaint */}
          <div className="lg:col-span-3 bg-slate-950/80 border border-slate-800 rounded-xl p-4 relative group">
            <div className="flex items-center justify-between mb-2">
              <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider">
                <FileText className="w-3.5 h-3.5" />
                1. Citizen Input
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">Single Text</span>
            </div>
            <p className="text-xs text-slate-300 italic font-mono bg-slate-900/90 p-3 rounded-lg border border-slate-800 leading-relaxed">
              "{selectedSample.originalText}"
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
              <span>Bilingual / Tanglish</span>
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Validated
              </span>
            </div>
          </div>

          {/* Flow Connector Arrow */}
          <div className="hidden lg:flex lg:col-span-1 justify-center items-center">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-400/30 animate-pulse">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Step 2: AI Routing & NLP Engine */}
          <div className="lg:col-span-3 bg-gradient-to-br from-blue-950/70 to-indigo-950/70 border border-blue-800/50 rounded-xl p-4 shadow-lg shadow-blue-950/50">
            <div className="flex items-center justify-between mb-2">
              <span className="flex items-center gap-1.5 text-xs font-bold text-blue-400 uppercase tracking-wider">
                <Cpu className="w-3.5 h-3.5" />
                2. AI Router Core
              </span>
              <span className="text-[10px] bg-blue-500/30 text-blue-300 px-2 py-0.5 rounded font-mono font-bold">
                97% Conf
              </span>
            </div>

            <div className="space-y-2 py-1 text-xs">
              <div className="flex items-center justify-between p-2 rounded bg-slate-900/80 border border-blue-900/40">
                <span className="text-slate-400">Multi-Issue Detection</span>
                <span className="font-bold text-blue-300">{selectedSample.detectedIssues.length} Sub-Issues</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-900/80 border border-blue-900/40">
                <span className="text-slate-400">SLA Matrix Mapping</span>
                <span className="font-bold text-emerald-300">Auto-Calculated</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-900/80 border border-blue-900/40">
                <span className="text-slate-400">Duplicate Shield</span>
                <span className="font-bold text-amber-300">Verified Unique</span>
              </div>
            </div>
          </div>

          {/* Flow Connector Arrow */}
          <div className="hidden lg:flex lg:col-span-1 justify-center items-center">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/30 animate-pulse">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Step 3: Multi-Department Splitting */}
          <div className="lg:col-span-4 space-y-2.5">
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center justify-between mb-1">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                3. Parallel Department Dispatch
              </span>
              <span className="text-[10px] text-slate-400">Instant Routing</span>
            </div>

            {selectedSample.detectedIssues.map((issue, idx) => {
              const Icon = issue.icon;
              return (
                <div
                  key={idx}
                  className="bg-slate-950/90 border border-slate-800 rounded-xl p-3 hover:border-slate-700 transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-400/30 text-blue-400 flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-100">{issue.title}</h4>
                        <span className="text-[11px] text-slate-400 font-medium">{issue.department}</span>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase shrink-0 ${
                        issue.priority === 'Critical'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : issue.priority === 'High'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      }`}
                    >
                      {issue.priority}
                    </span>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-slate-300">
                      <Clock className="w-3 h-3 text-amber-400" />
                      SLA: <strong className="text-white">{issue.deadline}</strong>
                    </span>
                    <span className="text-slate-400 truncate max-w-[140px]">{issue.officer}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
