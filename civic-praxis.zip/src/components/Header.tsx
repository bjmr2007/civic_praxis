import React from 'react';
import { UserRole, AuthenticatedUser } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { LANGUAGE_OPTIONS, SupportedLanguage } from '../data/translations';
import {
  Bell,
  Shield,
  Sparkles,
  LogIn,
  LogOut,
  Globe2,
} from 'lucide-react';

interface HeaderProps {
  currentRole: UserRole;
  currentUser: AuthenticatedUser | null;
  onRoleChange: (role: UserRole) => void;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
  unreadCount: number;
  onOpenNotifications: () => void;
  hasGeminiKey?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  currentUser,
  onRoleChange,
  onOpenAuthModal,
  onSignOut,
  unreadCount,
  onOpenNotifications,
  hasGeminiKey = true,
}) => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top National Official Header Bar */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950 text-white text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          {/* National Emblem badge */}
          <div className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-[10px] text-amber-300 font-black">
            🇮🇳
          </div>
          <span className="font-semibold tracking-wide text-slate-200 uppercase text-[11px]">
            {t.nationalHeader}
          </span>
          <span className="hidden md:inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            {hasGeminiKey ? 'AI NLP Routing Core Active' : 'National Multilingual NLP Engine'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Language selector */}
          <div className="flex items-center gap-1.5 text-[11px] text-slate-300 bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 hover:border-white/20 transition-all">
            <Globe2 className="w-3.5 h-3.5 text-blue-300" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
              aria-label="Select Language"
              className="bg-transparent text-white text-[11px] font-semibold focus:outline-none cursor-pointer"
            >
              {LANGUAGE_OPTIONS.map((opt) => (
                <option key={opt.code} value={opt.code} className="bg-slate-900 text-white">
                  {opt.nativeName} ({opt.label})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Brand & Actions Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand identity */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-700 via-indigo-600 to-slate-900 text-white flex items-center justify-center shadow-md shadow-blue-600/20 ring-2 ring-blue-100">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                CIVIC <span className="text-blue-600">PRAXIS</span>
              </h1>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                <Sparkles className="w-3 h-3 text-blue-600" />
                Auto-Routing Platform
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* User Role & Notification Actions */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            <div className="flex items-center gap-2 bg-slate-100 pl-3 pr-1.5 py-1 rounded-xl border border-slate-200 text-xs">
              <div className="flex flex-col">
                <span className="font-bold text-slate-800 text-[11px]">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-blue-600 font-medium">
                  {currentUser.role === 'collector'
                    ? `District Collector (${currentUser.district})`
                    : currentUser.role === 'officer'
                    ? currentUser.department
                    : currentUser.role === 'state_admin'
                    ? `State Admin (${currentUser.state})`
                    : 'National Admin'}
                </span>
              </div>
              <button
                onClick={onSignOut}
                className="ml-2 px-2.5 py-1 rounded-lg bg-white hover:bg-rose-50 text-rose-600 border border-slate-200 hover:border-rose-200 text-[11px] font-bold transition-colors flex items-center gap-1 cursor-pointer"
                title="Sign out to citizen mode"
              >
                <LogOut className="w-3 h-3" />
                <span>{t.logout}</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>{t.citizenPortal}</span>
              </div>
              <button
                onClick={onOpenAuthModal}
                id="btn-officer-login"
                className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5 text-blue-400" />
                <span>{t.officialLogin}</span>
              </button>
            </div>
          )}

          {/* Notifications Center button */}
          <button
            onClick={onOpenNotifications}
            id="btn-notifications"
            className="relative p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            title="Notification Center"
          >
            <Bell className="w-5 h-5 text-slate-700" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center border-2 border-white animate-pulse">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
