import React, { useState } from 'react';
import { Complaint, ComplaintStatus, UserRole } from '../types';
import { IssueCard } from '../components/IssueCard';
import { FeedbackModal } from '../components/FeedbackModal';
import {
  Search,
  CheckCircle2,
  Clock,
  MapPin,
  Building2,
  Calendar,
  AlertTriangle,
  User,
  Star,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Phone,
  ShieldCheck,
} from 'lucide-react';

interface TrackComplaintPageProps {
  complaints: Complaint[];
  initialComplaintId?: string;
  userRole: UserRole;
  onUpdateIssueStatus?: (complaintId: string, issueId: string, newStatus: string) => void;
  onSubmitFeedback: (data: any) => void;
}

export const TrackComplaintPage: React.FC<TrackComplaintPageProps> = ({
  complaints,
  initialComplaintId = '',
  userRole,
  onUpdateIssueStatus,
  onSubmitFeedback,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>(initialComplaintId || 'IND-GRV-2026-10234');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(
    complaints.find((c) => c.id === (initialComplaintId || 'IND-GRV-2026-10234')) || complaints[0] || null
  );
  const [isFeedbackOpen, setIsFeedbackOpen] = useState<boolean>(false);
  const [activeFeedbackIssue, setActiveFeedbackIssue] = useState<any>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.toLowerCase().trim();
    const found = complaints.find(
      (c) =>
        c.id.toLowerCase().includes(q) ||
        (c.citizen?.mobile && c.citizen.mobile.includes(q)) ||
        c.complaintTitle.toLowerCase().includes(q)
    );
    if (found) {
      setSelectedComplaint(found);
    } else {
      alert(`Complaint or Mobile "${searchQuery}" not found. Try one of the quick suggestions below.`);
    }
  };

  // Steps in the progress timeline
  const TIMELINE_STEPS = [
    { label: 'Grievance Filed', key: 'submitted' },
    { label: 'AI Decomposed', key: 'ai_processed' },
    { label: 'Department Routed', key: 'routed' },
    { label: 'Officer Dispatched', key: 'assigned' },
    { label: 'Field Work In Progress', key: 'in_progress' },
    { label: 'SLA Resolved', key: 'resolved' },
  ];

  const getStepProgress = (status: ComplaintStatus) => {
    switch (status) {
      case 'Closed':
      case 'Resolved':
        return 6;
      case 'In Progress':
        return 5;
      case 'Routed':
        return 4;
      case 'Pending':
      default:
        return 3;
    }
  };

  const currentProgress = selectedComplaint ? getStepProgress(selectedComplaint.overallStatus) : 0;

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      {/* Search Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="max-w-2xl mx-auto text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            Citizen Grievance Live Tracking
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Enter your CIVIC PRAXIS Reference Number (e.g. IND-GRV-2026-10234) or Citizen Mobile Number to inspect real-time status and department actions.
          </p>
        </div>

        <form onSubmit={handleSearch} className="max-w-xl mx-auto flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="e.g. IND-GRV-2026-10234 or mobile number"
              className="w-full px-4 py-3 rounded-2xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md shadow-blue-500/20 transition-all cursor-pointer flex items-center gap-2"
          >
            <Search className="w-4 h-4" />
            <span>Track</span>
          </button>
        </form>

        {/* Quick Reference Pills */}
        <div className="max-w-xl mx-auto mt-3 flex flex-wrap items-center justify-center gap-2 text-xs">
          <span className="text-slate-400 font-semibold">Active Grievance Dockets:</span>
          {complaints.slice(0, 4).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSearchQuery(c.id);
                setSelectedComplaint(c);
              }}
              className={`px-2.5 py-1 rounded-lg border text-xs font-mono transition-colors ${
                selectedComplaint?.id === c.id
                  ? 'bg-blue-50 border-blue-400 text-blue-700 font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {c.id}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Complaint Details */}
      {selectedComplaint ? (
        <div className="space-y-6 animate-fade-in">
          {/* Overview Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2.5">
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 font-mono">
                    {selectedComplaint.id}
                  </h3>
                  <span
                    className={`px-3 py-0.5 rounded-full text-xs font-black uppercase tracking-wide border ${
                      selectedComplaint.overallStatus === 'Resolved'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : selectedComplaint.overallStatus === 'In Progress'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}
                  >
                    {selectedComplaint.overallStatus}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-700 mt-1">
                  {selectedComplaint.complaintTitle}
                </h4>
              </div>

              <div className="text-right text-xs">
                <span className="text-slate-400 block font-medium">Filed Date</span>
                <strong className="text-slate-800 text-sm font-mono">
                  {new Date(selectedComplaint.dateFiled).toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </strong>
              </div>
            </div>

            {/* 7-Step Visual Progress Bar */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Resolution Lifecycle Progress:</span>
                <span className="text-blue-600">
                  Step {currentProgress} of {TIMELINE_STEPS.length}
                </span>
              </div>

              <div className="relative">
                {/* Background Line */}
                <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-100 -translate-y-1/2 rounded-full" />
                {/* Filled Line */}
                <div
                  className="absolute top-1/2 left-0 h-1 bg-blue-600 -translate-y-1/2 rounded-full transition-all duration-700"
                  style={{
                    width: `${((currentProgress - 1) / (TIMELINE_STEPS.length - 1)) * 100}%`,
                  }}
                />

                {/* Nodes */}
                <div className="relative flex justify-between">
                  {TIMELINE_STEPS.map((step, idx) => {
                    const isDone = idx < currentProgress;
                    const isCurrent = idx === currentProgress - 1;
                    return (
                      <div key={step.key} className="flex flex-col items-center">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-xs ${
                            isDone
                              ? 'bg-blue-600 text-white'
                              : 'bg-white border-2 border-slate-300 text-slate-400'
                          } ${isCurrent ? 'ring-4 ring-blue-100' : ''}`}
                        >
                          {isDone ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                        </div>
                        <span
                          className={`text-[10px] mt-2 hidden sm:block font-medium text-center max-w-[80px] leading-tight ${
                            isDone ? 'text-slate-800 font-bold' : 'text-slate-400'
                          }`}
                        >
                          {step.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Incident Context Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block mb-1 font-medium">Incident Location</span>
                <div className="flex items-start gap-1.5 font-bold text-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                  <span>
                    {selectedComplaint.location.area}, {selectedComplaint.location.district},{' '}
                    {selectedComplaint.location.state || 'India'}
                  </span>
                </div>
                {selectedComplaint.location.ward && (
                  <span className="text-[11px] text-slate-500 font-mono block mt-1">
                    {selectedComplaint.location.ward}
                  </span>
                )}
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block mb-1 font-medium">Citizen Information</span>
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <User className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  <span>{selectedComplaint.citizen.name}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-mono mt-1">
                  <Phone className="w-3 h-3 text-emerald-600" />
                  <span>{selectedComplaint.citizen.mobile} (Verified)</span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block mb-1 font-medium">AI Auto-Triage Core</span>
                <div className="flex items-center gap-1.5 font-bold text-blue-700">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>{selectedComplaint.aiEngineUsed || 'Gemini 3.8 Flash'}</span>
                </div>
                <span className="text-[11px] text-slate-500 block mt-1">
                  Decomposed into {selectedComplaint.issuesDetected.length} parallel work orders
                </span>
              </div>
            </div>

            {/* Original Complaint Text Box */}
            <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 text-xs space-y-1">
              <span className="font-bold text-blue-900 block">Citizen Original Submission:</span>
              <p className="text-slate-700 italic">"{selectedComplaint.originalComplaint}"</p>
            </div>
          </div>

          {/* Department Work Orders */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight">
                  Dispatched Department Work Orders ({selectedComplaint.issuesDetected.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Each sub-issue is independently assigned to its department field engineering team.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setActiveFeedbackIssue(selectedComplaint.issuesDetected[0]);
                  setIsFeedbackOpen(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 text-xs font-bold transition-all cursor-pointer"
              >
                <Star className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                <span>Submit Citizen Feedback</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {selectedComplaint.issuesDetected.map((issue) => (
                <IssueCard
                  key={issue.id}
                  issue={issue}
                  isOfficer={userRole === 'officer' || userRole === 'collector'}
                  onUpdateStatus={
                    onUpdateIssueStatus
                      ? (newStatus) => onUpdateIssueStatus(selectedComplaint.id, issue.id, newStatus)
                      : undefined
                  }
                  onOpenFeedback={() => {
                    setActiveFeedbackIssue(issue);
                    setIsFeedbackOpen(true);
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400">
          <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm font-medium">Select or search a complaint to track live progress.</p>
        </div>
      )}

      {/* Citizen Feedback Modal */}
      {isFeedbackOpen && selectedComplaint && (
        <FeedbackModal
          isOpen={isFeedbackOpen}
          onClose={() => setIsFeedbackOpen(false)}
          complaintId={selectedComplaint.id}
          citizenName={selectedComplaint.citizen.name}
          department={activeFeedbackIssue?.department || 'Municipal Corporation / Sanitation'}
          onSubmitFeedback={onSubmitFeedback}
        />
      )}
    </div>
  );
};
