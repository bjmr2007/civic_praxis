import React, { useState, useEffect } from 'react';
import { Complaint, Priority } from '../types';
import { IssueCard } from '../components/IssueCard';
import { INDIAN_STATES } from '../data/indiaLocations';
import { useLanguage } from '../context/LanguageContext';
import {
  MapPin,
  Sparkles,
  Send,
  AlertCircle,
  CheckCircle2,
  Cpu,
  Layers,
  FileText,
  Clock,
  ArrowRight,
  Shield,
  Smartphone,
  Mic,
  MicOff,
  Check,
  KeyRound,
  MessageSquare,
  Crosshair,
  RefreshCw,
  Navigation,
  Trash2,
  Search,
  Mail,
  Compass,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SubmitComplaintPageProps {
  onComplaintSubmitted: (complaint: Complaint) => void;
  onNavigateTrack: (complaintId: string) => void;
}

export const SubmitComplaintPage: React.FC<SubmitComplaintPageProps> = ({
  onComplaintSubmitted,
  onNavigateTrack,
}) => {
  const { t, language } = useLanguage();

  // Citizen Profile
  const [citizenName, setCitizenName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [preferredLanguage, setPreferredLanguage] = useState<string>('Auto Detect');

  // Real OTP Verification State
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpValue, setOtpValue] = useState<string>('');
  const [phoneVerified, setPhoneVerified] = useState<boolean>(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);
  const [otpMessage, setOtpMessage] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState<number>(0);

  // Resend OTP Cooldown Timer
  useEffect(() => {
    let timer: any;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [resendCooldown]);

  // Location State - defaults to first state
  const [selectedState, setSelectedState] = useState<string>('Maharashtra');
  const currentStateObj =
    INDIAN_STATES.find(
      (s) => s.name.toLowerCase() === selectedState.toLowerCase() || s.stateName?.toLowerCase() === selectedState.toLowerCase()
    ) || INDIAN_STATES[0];
  const currentDistricts = currentStateObj.districts;

  const [district, setDistrict] = useState<string>(currentDistricts[0] || '');
  const [taluk, setTaluk] = useState<string>('');
  const [village, setVillage] = useState<string>('');
  const [ward, setWard] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [pincode, setPincode] = useState<string>('');

  // Complaint Content
  const [complaintTitle, setComplaintTitle] = useState<string>('');
  const [complaintText, setComplaintText] = useState<string>('');
  const [priorityHint, setPriorityHint] = useState<Priority>('High');
  const [dateFiled] = useState<string>(new Date().toISOString().slice(0, 10));

  // Geolocation & Auto Address Fill
  const [locationStatus, setLocationStatus] = useState<string>('');
  const [coords, setCoords] = useState<{ lat: number; lng: number }>({ lat: 19.076, lng: 72.8777 });
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [isAutoFilledFromLocation, setIsAutoFilledFromLocation] = useState<boolean>(false);
  const [autoLocationEnabled, setAutoLocationEnabled] = useState<boolean>(() => {
    return localStorage.getItem('civic_auto_detect_location') === 'true';
  });

  // Reverse Geocoding: Converts GPS (lat, lng) to full Indian Address details
  const reverseGeocodeAndFillAddress = async (latitude: number, longitude: number) => {
    setLocationStatus('Querying GIS Reverse-Geocode for address details...');
    try {
      const res = await fetch(`/api/geocode/reverse?lat=${latitude}&lng=${longitude}`);
      if (!res.ok) {
        throw new Error('Geocoding service unavailable');
      }
      const data = await res.json();
      if (data && data.address) {
        const addr = data.address;

        // 1. Match State in INDIAN_STATES
        const rawState = (addr.state || '').toLowerCase().trim();
        const matchedState = INDIAN_STATES.find(
          (s) =>
            s.name.toLowerCase() === rawState ||
            rawState.includes(s.name.toLowerCase()) ||
            s.name.toLowerCase().includes(rawState)
        );

        if (matchedState) {
          setSelectedState(matchedState.name);

          // 2. Match District in matchedState.districts
          const rawDistrict = (addr.district || '').toLowerCase().trim();
          const matchedDistrict = matchedState.districts.find(
            (d) =>
              d.toLowerCase() === rawDistrict ||
              rawDistrict.includes(d.toLowerCase()) ||
              d.toLowerCase().includes(rawDistrict)
          );

          if (matchedDistrict) {
            setDistrict(matchedDistrict);
          } else if (matchedState.districts.length > 0) {
            setDistrict(matchedState.districts[0]);
          }
        }

        // 3. Fill Taluk, Village, Ward, Address, and Pincode
        if (addr.taluk) setTaluk(addr.taluk);
        if (addr.village || addr.taluk) setVillage(addr.village || addr.taluk);
        if (addr.ward) setWard(addr.ward);
        if (addr.address) setAddress(addr.address);
        if (addr.pincode) setPincode(addr.pincode);

        setIsAutoFilledFromLocation(true);
        const locationName = addr.village || addr.taluk || addr.district || 'Current Location';
        const stateName = matchedState?.name || addr.state || '';
        setLocationStatus(`✓ Auto-filled: ${locationName}, ${stateName} ${addr.pincode ? `(${addr.pincode})` : ''}`);
      }
    } catch (err) {
      console.warn('[GEOCODE ERROR]', err);
      setLocationStatus(`GPS Locked: ${latitude.toFixed(4)}° N, ${longitude.toFixed(4)}° E`);
    }
  };

  // Handle GPS location & Address Auto-fill
  const handleUseCurrentLocation = (explicitClick: boolean = true) => {
    if (!navigator.geolocation) {
      setLocationStatus('Geolocation is not supported by your browser');
      return;
    }
    setIsLocating(true);
    setLocationStatus('Acquiring high-accuracy GPS coordinates...');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setCoords({ lat: latitude, lng: longitude });
        await reverseGeocodeAndFillAddress(latitude, longitude);
        setIsLocating(false);
      },
      async (err) => {
        console.warn('Geolocation acquisition error:', err);
        setIsLocating(false);
        if (explicitClick) {
          // If browser blocked permission or timed out, inform citizen and provide fallback
          setLocationStatus('Could not read GPS. Falling back to regional coordinates.');
          await reverseGeocodeAndFillAddress(19.076, 72.8777);
        }
      },
      { timeout: 9000, enableHighAccuracy: true, maximumAge: 60000 }
    );
  };

  // Toggle Auto-Detect Location on page load
  const toggleAutoLocationOption = (enable: boolean) => {
    setAutoLocationEnabled(enable);
    localStorage.setItem('civic_auto_detect_location', String(enable));
    if (enable) {
      handleUseCurrentLocation(true);
    }
  };

  // Auto-detect address if preference was previously enabled
  useEffect(() => {
    if (autoLocationEnabled) {
      handleUseCurrentLocation(false);
    }
  }, []);

  // Speech Recognition
  const [isListening, setIsListening] = useState<boolean>(false);

  // Processing & Results
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStep, setAnalysisStep] = useState<string>('');
  const [submittedResult, setSubmittedResult] = useState<any>(null);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  // State Change handler
  const handleStateChange = (newState: string) => {
    setSelectedState(newState);
    const found = INDIAN_STATES.find(
      (s) => s.name.toLowerCase() === newState.toLowerCase() || s.stateName?.toLowerCase() === newState.toLowerCase()
    );
    if (found && found.districts.length > 0) {
      setDistrict(found.districts[0]);
    }
  };

  // Real OTP: Send
  const handleSendOtp = async () => {
    const cleanNumber = mobileNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      setOtpError('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    setIsVerifyingOtp(true);
    setOtpError(null);
    setOtpMessage(null);

    try {
      const res = await fetch('/api/otp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobileNumber: cleanNumber, citizenName: citizenName.trim() }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to dispatch verification code');
      }

      setOtpSent(true);
      setOtpValue(''); // Keep empty so citizen inputs the SMS code received on mobile
      setResendCooldown(30);
      setOtpMessage(
        data.message ||
          `Verification code sent via SMS to +91 ${cleanNumber.slice(0, 3)}****${cleanNumber.slice(-3)}. Check your phone.`
      );
    } catch (err: any) {
      setOtpError(err.message || 'Unable to send OTP. Please check your mobile number.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Real OTP: Verify
  const handleVerifyOtp = async () => {
    const cleanNumber = mobileNumber.replace(/\D/g, '');
    const code = otpValue.trim();
    if (!code || code.length !== 6) {
      setOtpError('Please enter the 6-digit verification code received on your mobile phone.');
      return;
    }

    setIsVerifyingOtp(true);
    setOtpError(null);

    try {
      const res = await fetch('/api/otp/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobileNumber: cleanNumber, otp: code }),
      });

      const data = await res.json();
      if (!res.ok || !data.verified) {
        throw new Error(data.error || 'Invalid OTP code. Please check your SMS and try again.');
      }

      setPhoneVerified(true);
      setOtpMessage('Mobile number verified successfully.');
    } catch (err: any) {
      setOtpError(err.message || 'Verification failed. Please check the code received on your phone.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Voice Input Toggle (Web Speech API)
  const toggleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Voice dictation is supported in Chrome, Edge, and Safari. You can also type directly in any Indian language.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang =
        preferredLanguage === 'Tamil'
          ? 'ta-IN'
          : preferredLanguage === 'Hindi'
          ? 'hi-IN'
          : preferredLanguage === 'Telugu'
          ? 'te-IN'
          : preferredLanguage === 'Bengali'
          ? 'bn-IN'
          : preferredLanguage === 'Marathi'
          ? 'mr-IN'
          : preferredLanguage === 'Kannada'
          ? 'kn-IN'
          : 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setComplaintText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  // Handle Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionError(null);

    if (!citizenName.trim()) {
      setSubmissionError('Please provide your full name.');
      return;
    }

    const cleanNumber = mobileNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      setSubmissionError('Please provide a valid 10-digit Indian mobile number.');
      return;
    }

    if (!complaintText.trim()) {
      setSubmissionError('Please describe your civic grievance.');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisStep('Detecting Indian language & extracting syntactic intent...');

    try {
      setTimeout(() => {
        setAnalysisStep('Decomposing multiple issues & classifying departments...');
      }, 700);

      setTimeout(() => {
        setAnalysisStep('Assigning Citizen Charter SLAs and geo-routing work orders...');
      }, 1400);

      const response = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          citizenName: citizenName.trim(),
          mobileNumber: cleanNumber,
          complaintTitle: complaintTitle.trim() || complaintText.slice(0, 50),
          complaintText: complaintText.trim(),
          priorityHint,
          preferredLanguage,
          state: selectedState,
          district,
          taluk: taluk.trim() || district,
          village: village.trim() || district,
          ward: ward.trim() || 'General Ward',
          address: address.trim(),
          pincode: pincode.trim(),
          coords,
        }),
      });

      const data = await response.json();
      setIsAnalyzing(false);

      if (data.full_complaint) {
        setSubmittedResult(data);
        onComplaintSubmitted(data.full_complaint);
        try {
          confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
        } catch {
          // ignore
        }
      } else {
        throw new Error(data.error || 'Failed to route complaint');
      }
    } catch (err: any) {
      console.error('Submission failed:', err);
      setIsAnalyzing(false);
      setSubmissionError(err.message || 'Submission failed. Please try again.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-4 space-y-6">
      {/* Title Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <FileText className="w-5 h-5" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {t.submitGrievance}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {t.submitSubtitle}
          </p>
        </div>

        {/* Free Citizen Access Badge */}
        <div className="bg-emerald-50 border border-emerald-200 px-3.5 py-1.5 rounded-xl text-right">
          <span className="text-[10px] uppercase font-bold text-emerald-800 flex items-center justify-end gap-1">
            <Check className="w-3 h-3 text-emerald-600" /> Free Citizen Access
          </span>
          <span className="text-xs font-bold text-slate-800 font-mono">
            Direct Mobile Verification
          </span>
        </div>
      </div>

      {/* Submission Error Banner */}
      {submissionError && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{submissionError}</span>
        </div>
      )}

      {/* Processing Animation */}
      {isAnalyzing && (
        <div className="bg-white rounded-3xl border border-blue-200 p-8 shadow-md text-center space-y-4 animate-fade-in">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-600 text-white flex items-center justify-center animate-bounce shadow-lg shadow-blue-500/30">
            <Cpu className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">CIVIC PRAXIS AI Engine Processing</h3>
            <p className="text-xs text-blue-600 font-medium mt-1 animate-pulse">{analysisStep}</p>
          </div>
          <div className="max-w-md mx-auto h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-blue-600 animate-[pulse_1s_infinite] w-3/4 rounded-full" />
          </div>
        </div>
      )}

      {/* Submission Result Display */}
      {submittedResult && (
        <div className="bg-white rounded-3xl border border-emerald-300 p-6 sm:p-8 shadow-lg space-y-6 animate-fade-in">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/20">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wide">
                  Submission Successful & Auto-Routed
                </span>
                <h3 className="text-xl font-black text-slate-900 font-mono">
                  {submittedResult.complaint_id}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                Language: {submittedResult.detected_language}
              </span>
              <button
                type="button"
                onClick={() => {
                  setSubmittedResult(null);
                  setComplaintText('');
                  setComplaintTitle('');
                }}
                className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700 transition-colors cursor-pointer"
              >
                File Another Complaint
              </button>
            </div>
          </div>

          {/* AI Decomposition Summary Card */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-blue-600" />
                AI Decomposition & Citizen Charter Routing
              </span>
              <span className="text-xs font-semibold text-emerald-700">
                {submittedResult.issues_detected?.length || 0} Distinct Work Orders Generated
              </span>
            </div>
            <p className="text-xs text-slate-600">{submittedResult.summary}</p>
          </div>

          {/* Dispatched Issue Cards */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Dispatched Government Work Orders:
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {submittedResult.full_complaint?.issuesDetected?.map((issue: any) => (
                <IssueCard key={issue.id} issue={issue} />
              ))}
            </div>
          </div>

          {/* SMS Confirmation Box */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>Instant Citizen SMS & WhatsApp Confirmation Dispatched:</span>
            </div>
            <div className="p-3 bg-white rounded-xl border border-emerald-200 font-mono text-xs text-slate-700">
              <strong>CIVIC PRAXIS</strong>: Your complaint {submittedResult.complaint_id} has been logged and split into {submittedResult.issues_detected?.length} department work orders with Citizen Charter SLAs. Track status anytime using your mobile number.
            </div>
          </div>

          {/* Action CTA */}
          <div className="pt-2 flex justify-end">
            <button
              onClick={() => onNavigateTrack(submittedResult.complaint_id)}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <span>Track Live Resolution Timeline</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Submission Form */}
      {!submittedResult && !isAnalyzing && (
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          {/* 1. Citizen Identity & Real Mobile Verification */}
          <div className="space-y-4 pb-6 border-b border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span>1. Citizen Profile & Mobile Verification</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-medium">
                Direct SMS OTP Verification
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Citizen Full Name *</label>
                <input
                  type="text"
                  required
                  value={citizenName}
                  onChange={(e) => setCitizenName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. Rahul Sharma"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Mobile Number (10 digits) *</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs">+91</span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={mobileNumber}
                      onChange={(e) => {
                        setMobileNumber(e.target.value);
                        setPhoneVerified(false);
                        setOtpSent(false);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                      placeholder="9876543210"
                    />
                  </div>
                  {!phoneVerified && (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      disabled={isVerifyingOtp}
                      className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs whitespace-nowrap cursor-pointer transition-all disabled:opacity-50"
                    >
                      {isVerifyingOtp ? 'Sending...' : otpSent ? 'Resend OTP' : 'Send OTP'}
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Preferred Language</label>
                <select
                  value={preferredLanguage}
                  onChange={(e) => setPreferredLanguage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="Auto Detect">Auto Detect (Any Language)</option>
                  <option value="Hindi">हिंदी (Hindi)</option>
                  <option value="Tamil">தமிழ் (Tamil)</option>
                  <option value="Telugu">తెలుగు (Telugu)</option>
                  <option value="Kannada">ಕನ್ನಡ (Kannada)</option>
                  <option value="Bengali">বাংলা (Bengali)</option>
                  <option value="Marathi">मराठी (Marathi)</option>
                  <option value="English">English</option>
                </select>
              </div>
            </div>

            {/* OTP Verification Box (Real SMS delivery - Code NOT shown on page) */}
            {otpSent && !phoneVerified && (
              <div className="p-4 bg-slate-50 rounded-2xl border border-blue-200 space-y-3 shadow-xs animate-fade-in">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-blue-900 font-bold text-xs">
                    <MessageSquare className="w-4 h-4 text-blue-600" />
                    <span>SMS OTP dispatched to +91 {mobileNumber}</span>
                  </div>
                  <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                    Official Telecom Delivery
                  </span>
                </div>

                <p className="text-xs text-slate-600">
                  Please check the SMS inbox on your mobile phone and enter the 6-digit verification code below:
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={6}
                      value={otpValue}
                      onChange={(e) => setOtpValue(e.target.value.replace(/\D/g, ''))}
                      placeholder="••••••"
                      className="w-36 pl-9 pr-3 py-2 bg-white border border-slate-300 focus:border-blue-600 rounded-xl font-mono font-bold text-center text-base tracking-widest focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleVerifyOtp}
                    disabled={isVerifyingOtp || otpValue.length !== 6}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>{isVerifyingOtp ? 'Verifying...' : 'Verify OTP'}</span>
                  </button>

                  <div className="text-xs text-slate-500 ml-auto">
                    {resendCooldown > 0 ? (
                      <span className="text-slate-400 font-medium">Resend OTP in {resendCooldown}s</span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        disabled={isVerifyingOtp}
                        className="text-blue-600 hover:underline font-bold cursor-pointer"
                      >
                        Resend SMS OTP
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Feedback messages */}
            {otpError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{otpError}</span>
              </div>
            )}

            {phoneVerified && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-semibold">Mobile number +91 {mobileNumber} verified.</span>
              </div>
            )}
          </div>

          {/* 2. Problem Location Across All 36 States & Districts */}
          <div className="space-y-4 pb-6 border-b border-slate-200">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>2. Incident Location & Address Details</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Provide or automatically detect the incident location across all 36 States & Union Territories.
                </p>
              </div>

              {/* Main Action: Auto-Detect & Fill All Address Details */}
              <button
                type="button"
                onClick={() => handleUseCurrentLocation(true)}
                disabled={isLocating}
                id="btn-use-location"
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm hover:shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                <Crosshair className={`w-4 h-4 ${isLocating ? 'animate-spin text-blue-200' : 'text-white'}`} />
                <span>{isLocating ? 'Locating & Filling Address...' : '📍 Auto-Fill Address with Current GPS'}</span>
              </button>
            </div>

            {/* Location Option / Preference Card */}
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-2xl flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <input
                  type="checkbox"
                  id="auto-location-option"
                  checked={autoLocationEnabled}
                  onChange={(e) => toggleAutoLocationOption(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                />
                <label htmlFor="auto-location-option" className="text-xs font-semibold text-slate-800 cursor-pointer">
                  <span>Automatically detect my location & fill address on page load</span>
                  <span className="block text-[10px] text-slate-500 font-normal">
                    When enabled, GPS coordinates will instantly populate your State, District, Taluk, Area, and Pincode.
                  </span>
                </label>
              </div>

              <div className="flex items-center gap-2">
                {isAutoFilledFromLocation && (
                  <span className="text-[11px] bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    GPS Auto-Filled
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => handleUseCurrentLocation(true)}
                  disabled={isLocating}
                  className="text-xs text-blue-700 hover:text-blue-900 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${isLocating ? 'animate-spin' : ''}`} />
                  Refresh GPS
                </button>
              </div>
            </div>

            {locationStatus && (
              <div className={`p-2.5 rounded-xl border text-xs font-mono flex items-center justify-between gap-2 ${
                isAutoFilledFromLocation
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}>
                <div className="flex items-center gap-2">
                  <Navigation className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>{locationStatus}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-sans hidden sm:inline">
                  Lat: {coords.lat.toFixed(4)}, Lng: {coords.lng.toFixed(4)}
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">State / UT *</label>
                <select
                  value={selectedState}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  {INDIAN_STATES.map((s) => (
                    <option key={s.name} value={s.name}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">District *</label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  {currentDistricts.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Taluk / Tehsil / Sub-District</label>
                <input
                  type="text"
                  value={taluk}
                  onChange={(e) => setTaluk(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. Mambalam / Andheri / Haveli"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Area / Village / Locality *</label>
                <input
                  type="text"
                  required
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. T. Nagar / Main Market Road"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Detailed Street Address / Landmark</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. Near Water Tank or Bus Depot"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Ward / Zone</label>
                  <input
                    type="text"
                    value={ward}
                    onChange={(e) => setWard(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="e.g. Ward 12"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Pincode *</label>
                  <input
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                    placeholder="e.g. 600017"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 3. Main Grievance Description with Voice Support */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                <span>3. Grievance Description</span>
              </h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={toggleVoiceInput}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    isListening
                      ? 'bg-rose-500 text-white animate-pulse'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                  title="Voice Input (Speech-to-Text)"
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-blue-600" />}
                  <span>{isListening ? 'Listening...' : 'Voice Dictate'}</span>
                </button>
                <span className="text-[11px] text-blue-600 font-medium hidden sm:inline">
                  Any Indian language supported
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Complaint Title (Optional)</label>
                <input
                  type="text"
                  value={complaintTitle}
                  onChange={(e) => setComplaintTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="Brief headline (or leave empty for AI auto-summary)"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Priority Hint</label>
                <select
                  value={priorityHint}
                  onChange={(e) => setPriorityHint(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1.5">
                Main Grievance Details *
              </label>
              <textarea
                required
                rows={4}
                value={complaintText}
                onChange={(e) => setComplaintText(e.target.value)}
                className="w-full p-3.5 rounded-2xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm leading-relaxed"
                placeholder="Describe the civic issue in your own words. You can write in Hindi, Tamil, Telugu, Kannada, Bengali, Marathi, English, or your regional language..."
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Tip: You can mention multiple problems simultaneously (e.g. broken road + no water + sewage overflow). CIVIC PRAXIS will automatically decompose them into separate work orders for each department.
              </p>
            </div>
          </div>

          {/* Submit Action Button */}
          <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Clock className="w-4 h-4 text-amber-500" />
              <span>Date: <strong>{dateFiled}</strong></span>
            </div>

            <button
              type="submit"
              id="btn-submit-complaint"
              className="px-8 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-sm flex items-center gap-2.5 shadow-lg shadow-blue-600/30 transition-all cursor-pointer hover:translate-y-[-1px]"
            >
              <Send className="w-4 h-4" />
              <span>Submit Grievance</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
