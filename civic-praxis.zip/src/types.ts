export type Department =
  | 'Water Supply Department'
  | 'Electricity Department'
  | 'Public Works Department (PWD)'
  | 'Municipal Corporation / Sanitation'
  | 'Health Department'
  | 'Revenue Department'
  | 'Police Department'
  | 'Education Department'
  | 'Transport Department'
  | 'Housing Department'
  | 'Rural Development'
  | 'Disaster Management Authority'
  // Compatibility aliases
  | 'Water Board (Metro Water)'
  | 'Electricity Board (TANGEDCO)'
  | 'TANGEDCO (Electricity Board)'
  | 'Sanitation / Corporation'
  | 'Housing Board';

export type SupportedLanguage =
  | 'Auto Detect'
  | 'English'
  | 'Hindi'
  | 'Tamil'
  | 'Telugu'
  | 'Kannada'
  | 'Malayalam'
  | 'Bengali'
  | 'Marathi'
  | 'Gujarati'
  | 'Punjabi'
  | 'Urdu'
  | 'Odia'
  | 'Assamese';

export type Language = 'en' | 'hi' | 'ta' | 'te' | 'kn' | 'ml' | 'bn' | 'mr' | 'gu' | 'pa' | 'ur' | 'or' | 'as';

export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

export type ComplaintStatus = 'Pending' | 'Routed' | 'In Progress' | 'Resolved' | 'Closed';

export type UserRole = 'citizen' | 'officer' | 'collector' | 'state_admin' | 'national_admin';

export interface AuthenticatedUser {
  username: string;
  name: string;
  role: UserRole;
  department?: string;
  state?: string;
  district?: string;
  designation?: string;
}

export interface CitizenInfo {
  name: string;
  mobile: string; // Stored safely, displayed masked e.g. 98765XXXXX
  email?: string;
  state: string;
  district: string;
  taluk: string;
  village: string;
  ward?: string;
  address?: string;
  pincode: string;
  preferredLanguage: SupportedLanguage | string;
  phoneVerified: boolean;
  demoCitizenId?: string; // e.g. IND-CIT-10234
  maskedId?: string; // e.g. XXXX-XXXX-1234
}

export interface LocationInfo {
  country: string; // "India"
  state: string;
  district: string;
  city?: string;
  taluk: string;
  area: string;
  ward?: string;
  pincode?: string;
  latitude: number;
  longitude: number;
  addressDetails?: string;
}

export interface DetectedIssue {
  id: string;
  issueSummary: string;
  department: Department | string;
  requiredAction: string;
  deadline: string; // e.g. "24 Hours", "48 Hours", "7 Days"
  deadlineHours: number; // for SLA calculation
  priority: Priority;
  confidenceScore: number; // 0 - 100
  status: ComplaintStatus;
  assignedOfficer?: string;
  officerPhone?: string;
  resolvedAt?: string;
  createdAt?: string;
}

export interface Complaint {
  id: string; // e.g. IND-GRV-2026-10234
  complaintTitle: string;
  originalComplaint: string;
  detectedLanguage?: string;
  citizen: CitizenInfo;
  location: LocationInfo;
  issuesDetected: DetectedIssue[];
  dateFiled: string;
  overallStatus: ComplaintStatus;
  overallPriority: Priority;
  duplicateOf?: string;
  duplicateSimilarity?: number;
  aiEngineUsed: string;
  slaViolation?: boolean;
}

export interface NotificationItem {
  id: string;
  complaintId: string;
  recipientRole: 'citizen' | 'officer' | 'collector' | 'state_admin' | 'national_admin' | 'all';
  channel: 'in-app' | 'sms' | 'whatsapp' | 'email';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'status_update' | 'new_assignment' | 'sla_warning' | 'critical_alert';
}

export interface Hotspot {
  id: string;
  locationName: string;
  state: string;
  district: string;
  issueType: string;
  department: Department | string;
  complaintCount: number;
  recommendedAction: string;
  severity: Priority;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface PredictiveRisk {
  id: string;
  title: string;
  riskLevel: Priority;
  location: string;
  state?: string;
  district: string;
  triggerFactors: string[];
  aiPrediction: string;
  recommendedProactiveAction: string;
  historicalPrecedent: string;
  confidence: number;
  timeframe: string;
  department?: Department | string;
  description?: string;
  recommendedPreventiveAction?: string;
  timeline?: string;
  probability?: number;
}

export interface CitizenFeedback {
  complaintId: string;
  citizenName: string;
  rating: number; // 1 to 5
  comments: string;
  department: Department | string;
  createdAt: string;
}

export interface DepartmentSummary {
  department: Department | string;
  icon: string;
  total: number;
  pending: number;
  inProgress: number;
  resolved: number;
  overdue: number;
  avgResolutionDays: number;
  slaCompliance: number;
}
