import React, { useState } from 'react';
import { Complaint, Department, UserRole } from '../types';
import { IssueCard } from '../components/IssueCard';
import { NATIONAL_DEPARTMENTS_CONFIG, INDIAN_STATES } from '../data/indiaLocations';
import {
  Building2,
  Droplets,
  Zap,
  Trash2,
  Construction,
  HeartPulse,
  Landmark,
  Shield,
  GraduationCap,
  Bus,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Phone,
  User,
  ExternalLink,
  ChevronRight,
  Filter,
} from 'lucide-react';

interface DepartmentViewPageProps {
  complaints: Complaint[];
  userRole: UserRole;
  onUpdateIssueStatus: (complaintId: string, issueId: string, newStatus: string) => void;
}

export const DepartmentViewPage: React.FC<DepartmentViewPageProps> = ({
  complaints,
  userRole,
  onUpdateIssueStatus,
}) => {
  const [selectedDeptName, setSelectedDeptName] = useState<string>(
    'Water Supply Department'
  );
  const [selectedState, setSelectedState] = useState<string>('All');

  // Map icon names to Lucide icons
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Droplets':
        return Droplets;
      case 'Zap':
        return Zap;
      case 'Construction':
        return Construction;
      case 'Trash2':
        return Trash2;
      case 'HeartPulse':
        return HeartPulse;
      case 'Shield':
        return Shield;
      case 'Landmark':
        return Landmark;
      case 'Bus':
        return Bus;
      case 'GraduationCap':
        return GraduationCap;
      case 'Flame':
      default:
        return Flame;
    }
  };

  const currentDeptConfig =
    NATIONAL_DEPARTMENTS_CONFIG.find((d) => d.name === selectedDeptName) ||
    NATIONAL_DEPARTMENTS_CONFIG[0];

  // Extract all sub-issues assigned to this department across complaints
  const assignedIssues: { issue: any; complaint: Complaint }[] = [];
  complaints.forEach((c) => {
    if (selectedState !== 'All' && c.location.state && c.location.state.toLowerCase() !== selectedState.toLowerCase()) {
      return;
    }
    c.issuesDetected.forEach((issue) => {
      // Match department name or aliases
      const match =
        issue.department.toLowerCase() === selectedDeptName.toLowerCase() ||
        currentDeptConfig.aliases.some((alias) =>
          issue.department.toLowerCase().includes(alias.toLowerCase())
        );
      if (match) {
        assignedIssues.push({ issue, complaint: c });
      }
    });
  });

  const totalAssigned = assignedIssues.length;
  const resolvedCount = assignedIssues.filter((item) => item.issue.status === 'Resolved').length;
  const inProgressCount = assignedIssues.filter((item) => item.issue.status === 'In Progress').length;
  const pendingCount = assignedIssues.filter(
    (item) => item.issue.status === 'Pending' || item.issue.status === 'Routed'
  ).length;

  const DeptIcon = getIcon(currentDeptConfig.icon);

  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 text-blue-700">
              <Building2 className="w-5 h-5" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              National Department Work Order Portals
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Individual department views showing dedicated work queues, Citizen Charter statutory deadlines, and field engineering squads.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-slate-600 font-medium">Filter by State:</span>
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none"
          >
            <option value="All">All States (India)</option>
            {INDIAN_STATES.slice(0, 12).map((s) => (
              <option key={s.code} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Department Selector Pills */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {NATIONAL_DEPARTMENTS_CONFIG.map((dept) => {
          const Icon = getIcon(dept.icon);
          const isSelected = dept.name === selectedDeptName;

          return (
            <button
              key={dept.name}
              type="button"
              onClick={() => setSelectedDeptName(dept.name)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl border text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{dept.name}</span>
            </button>
          );
        })}
      </div>

      {/* Selected Department Overview Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center shrink-0">
              <DeptIcon className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                {currentDeptConfig.name}
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-2xl">
                {currentDeptConfig.description}
              </p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase mr-1">Common State Aliases:</span>
                {currentDeptConfig.aliases.map((alias) => (
                  <span
                    key={alias}
                    className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-mono text-[10px]"
                  >
                    {alias}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="text-right text-xs space-y-1">
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-left">
              <span className="text-slate-400 block font-medium">Designated Head Officer</span>
              <strong className="text-slate-800 text-xs block">{currentDeptConfig.headOfficer}</strong>
              <span className="text-blue-600 font-mono text-[11px] block mt-0.5">
                Helpline: <strong>{currentDeptConfig.helpline}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Live Work Order Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 text-xs font-semibold block">Assigned Work Orders</span>
            <p className="text-2xl font-black text-slate-900 mt-1">{totalAssigned}</p>
            <span className="text-[10px] text-slate-400">Total active docket</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 text-xs font-semibold block">Under Active Repair</span>
            <p className="text-2xl font-black text-blue-600 mt-1">{inProgressCount}</p>
            <span className="text-[10px] text-blue-500 font-medium">Field crews on-site</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 text-xs font-semibold block">Pending Field Dispatch</span>
            <p className="text-2xl font-black text-amber-600 mt-1">{pendingCount}</p>
            <span className="text-[10px] text-amber-500 font-medium">Awaiting squad assignment</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-slate-500 text-xs font-semibold block">Citizen Charter SLA</span>
            <p className="text-2xl font-black text-emerald-600 mt-1">{currentDeptConfig.slaStandard}</p>
            <span className="text-[10px] text-emerald-600 font-medium">Statutory resolution guarantee</span>
          </div>
        </div>
      </div>

      {/* Active Work Orders Docket */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>Active Department Work Orders ({assignedIssues.length})</span>
          <span className="text-slate-400 font-normal">
            Officers can update status directly or add resolution comments
          </span>
        </div>

        {assignedIssues.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 text-slate-400">
            <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-500 opacity-60" />
            <p className="text-sm font-medium">
              No pending work orders for {currentDeptConfig.name} in selected state.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assignedIssues.map(({ issue, complaint }) => (
              <div key={issue.id} className="space-y-2">
                <div className="p-2.5 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <span className="font-mono text-blue-700">{complaint.id}</span>
                    <span>• {complaint.location.area}, {complaint.location.district}</span>
                  </div>
                  <span className="text-[11px] text-slate-500">Citizen: {complaint.citizen.name}</span>
                </div>

                <IssueCard
                  issue={issue}
                  isOfficer={true}
                  onUpdateStatus={(newStatus) =>
                    onUpdateIssueStatus(complaint.id, issue.id, newStatus)
                  }
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
