import React from 'react';
import { DetectedIssue, UserRole } from '../types';
import {
  Droplets,
  Zap,
  Trash2,
  Construction,
  HeartPulse,
  Landmark,
  Shield,
  GraduationCap,
  Bus,
  Building,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Flame,
  User,
  Phone,
  ArrowUpRight,
} from 'lucide-react';

interface IssueCardProps {
  issue: DetectedIssue;
  userRole?: UserRole;
  onUpdateStatus?: (issueId: string, newStatus: string) => void;
  complaintId?: string;
}

export const IssueCard: React.FC<IssueCardProps> = ({
  issue,
  userRole = 'citizen',
  onUpdateStatus,
  complaintId,
}) => {
  // Select appropriate icon based on department
  const getDepartmentIcon = (dept: string) => {
    const d = dept.toLowerCase();
    if (d.includes('water')) return { icon: Droplets, color: 'text-sky-600 bg-sky-50 border-sky-200' };
    if (d.includes('electr') || d.includes('tangedco')) return { icon: Zap, color: 'text-amber-600 bg-amber-50 border-amber-200' };
    if (d.includes('pwd') || d.includes('public works')) return { icon: Construction, color: 'text-orange-600 bg-orange-50 border-orange-200' };
    if (d.includes('sanitation') || d.includes('corporation')) return { icon: Trash2, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' };
    if (d.includes('health')) return { icon: HeartPulse, color: 'text-rose-600 bg-rose-50 border-rose-200' };
    if (d.includes('police')) return { icon: Shield, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' };
    if (d.includes('transport')) return { icon: Bus, color: 'text-cyan-600 bg-cyan-50 border-cyan-200' };
    if (d.includes('education')) return { icon: GraduationCap, color: 'text-purple-600 bg-purple-50 border-purple-200' };
    if (d.includes('revenue')) return { icon: Landmark, color: 'text-stone-600 bg-stone-50 border-stone-200' };
    return { icon: Building, color: 'text-blue-600 bg-blue-50 border-blue-200' };
  };

  const deptMeta = getDepartmentIcon(issue.department);
  const DeptIcon = deptMeta.icon;

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-red-50 text-red-700 border-red-200 ring-1 ring-red-300';
      case 'High':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'Medium':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Low':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Resolved':
      case 'Closed':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800 border-blue-200 animate-pulse';
      case 'Routed':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'Pending':
      default:
        return 'bg-amber-100 text-amber-800 border-amber-200';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between">
      {/* Top row */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${deptMeta.color}`}>
              <DeptIcon className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block">
                {issue.department}
              </span>
              <h4 className="text-base font-bold text-slate-900 leading-snug">
                {issue.issueSummary}
              </h4>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase border ${getPriorityBadge(issue.priority)}`}>
              {issue.priority === 'Critical' && <Flame className="w-3 h-3 inline mr-0.5 -mt-0.5" />}
              {issue.priority}
            </span>
            <span className="text-[10px] text-slate-600 font-medium">
              Conf: <strong className="text-slate-800">{issue.confidenceScore}%</strong>
            </span>
          </div>
        </div>

        {/* Required Action Box */}
        <div className="my-3 bg-slate-50 rounded-xl p-3 border border-slate-100">
          <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
            Required Action
          </span>
          <p className="text-xs font-medium text-slate-800 leading-relaxed">
            {issue.requiredAction}
          </p>
        </div>

        {/* Officer info */}
        {issue.assignedOfficer && (
          <div className="mb-3 text-xs text-slate-600 flex items-center justify-between bg-blue-50/50 px-3 py-1.5 rounded-lg border border-blue-100">
            <span className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-600" />
              <span className="truncate max-w-[190px] font-medium text-slate-700">{issue.assignedOfficer}</span>
            </span>
            {issue.officerPhone && (
              <span className="text-[11px] text-blue-700 font-mono flex items-center gap-1">
                <Phone className="w-3 h-3 text-blue-500" />
                {issue.officerPhone}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Footer info: SLA & Status */}
      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 mt-1">
        <div className="flex items-center gap-1.5 text-xs text-slate-600">
          <Clock className="w-3.5 h-3.5 text-amber-500" />
          <span>SLA Deadline:</span>
          <strong className="text-slate-900 font-semibold">{issue.deadline}</strong>
        </div>

        <div className="flex items-center gap-2">
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusBadge(issue.status)}`}>
            {issue.status}
          </span>

          {/* Quick status change controls for officers */}
          {userRole !== 'citizen' && onUpdateStatus && (
            <select
              value={issue.status}
              onChange={(e) => onUpdateStatus(issue.id, e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-lg px-2 py-1 font-semibold text-slate-800 hover:border-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="Pending">Pending</option>
              <option value="Routed">Routed</option>
              <option value="In Progress">In Progress</option>
              <option value="Resolved">Resolved</option>
              <option value="Closed">Closed</option>
            </select>
          )}
        </div>
      </div>
    </div>
  );
};
