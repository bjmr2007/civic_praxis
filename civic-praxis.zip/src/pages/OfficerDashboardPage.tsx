import React, { useState } from 'react';
import { Complaint, Department, Priority, ComplaintStatus, UserRole, AuthenticatedUser } from '../types';
import { IssueCard } from '../components/IssueCard';
import { INDIAN_STATES, NATIONAL_DEPARTMENTS_CONFIG } from '../data/indiaLocations';
import {
  LayoutDashboard,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Flame,
  Search,
  Filter,
  Download,
  Eye,
  Building2,
  Calendar,
  ChevronDown,
  ChevronUp,
  Sparkles,
  RefreshCw,
  MapPin,
  Shield,
  UserCheck,
} from 'lucide-react';

interface OfficerDashboardPageProps {
  complaints: Complaint[];
  userRole: UserRole;
  currentUser?: AuthenticatedUser | null;
  onUpdateIssueStatus: (complaintId: string, issueId: string, newStatus: string) => void;
  onSelectComplaintForTracking: (complaintId: string) => void;
  onOpenExportModal: () => void;
  onOpenAuthModal?: () => void;
}

export const OfficerDashboardPage: React.FC<OfficerDashboardPageProps> = ({
  complaints,
  userRole,
  currentUser,
  onUpdateIssueStatus,
  onSelectComplaintForTracking,
  onOpenExportModal,
  onOpenAuthModal,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterState, setFilterState] = useState<string>('All');
  const [filterDistrict, setFilterDistrict] = useState<string>('All');
  const [filterDept, setFilterDept] = useState<string>('All');
  const [filterPriority, setFilterPriority] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [expandedComplaintId, setExpandedComplaintId] = useState<string | null>(complaints[0]?.id || null);

  // Compute metrics
  const totalCount = complaints.length;
  const resolvedCount = complaints.filter(
    (c) => c.overallStatus === 'Resolved' || c.overallStatus === 'Closed'
  ).length;
  const pendingCount = complaints.filter(
    (c) => c.overallStatus === 'Pending' || c.overallStatus === 'Routed'
  ).length;
  const inProgressCount = complaints.filter((c) => c.overallStatus === 'In Progress').length;
  const criticalCount = complaints.filter((c) => c.overallPriority === 'Critical').length;

  // Filter complaints
  const filteredComplaints = complaints.filter((c) => {
    if (filterState !== 'All' && c.location.state?.toLowerCase() !== filterState.toLowerCase()) {
      return false;
    }
    if (filterDistrict !== 'All' && c.location.district.toLowerCase() !== filterDistrict.toLowerCase()) {
      return false;
    }
    if (filterPriority !== 'All' && c.overallPriority !== filterPriority) {
      return false;
    }
    if (filterStatus !== 'All' && c.overallStatus !== filterStatus) {
      return false;
    }
    if (filterDept !== 'All') {
      const hasDept = c.issuesDetected.some(
        (i) => i.department.toLowerCase() === filterDept.toLowerCase()
      );
      if (!hasDept) return false;
    }
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matchId = c.id.toLowerCase().includes(query);
      const matchCitizen = c.citizen.name.toLowerCase().includes(query);
      const matchArea = c.location.area.toLowerCase().includes(query);
      const matchDesc = c.originalComplaint.toLowerCase().includes(query);
      if (!matchId && !matchCitizen && !matchArea && !matchDesc) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      {/* Top Header & Export */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 text-blue-700">
              <LayoutDashboard className="w-5 h-5" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              National Grievance Command Center
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Real-time multi-state grievance triage, parallel work order dispatch, and field engineer SLA tracking across India.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {currentUser ? (
            <div className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800 flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>Logged in as: <strong>{currentUser.name}</strong></span>
            </div>
          ) : (
            onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Officer / Collector Login
              </button>
            )
          )}

          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs transition-all shadow-xs cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export Reports</span>
          </button>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Total Logged</span>
            <Building2 className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-black text-slate-900">{totalCount}</p>
          <span className="text-[10px] text-slate-400 font-medium">Pan-India Grievances</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>In Progress</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-black text-blue-600">{inProgressCount}</p>
          <span className="text-[10px] text-blue-500 font-medium">Field Crew Deployed</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Pending Triage</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-black text-amber-600">{pendingCount}</p>
          <span className="text-[10px] text-amber-500 font-medium">Auto-Routed to Officers</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>SLA Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-black text-emerald-600">{resolvedCount}</p>
          <span className="text-[10px] text-emerald-600 font-medium">96.8% Citizen Satisfaction</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Critical Priority</span>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-black text-rose-600">{criticalCount}</p>
          <span className="text-[10px] text-rose-500 font-medium">&lt; 24h SLA Escalations</span>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
          <Filter className="w-3.5 h-3.5 text-blue-600" />
          <span>Interactive National Filter Matrix</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
          {/* Search Query */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">Search Keyword / ID</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ID, citizen, locality..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* State Filter */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">State / UT</label>
            <select
              value={filterState}
              onChange={(e) => {
                setFilterState(e.target.value);
                setFilterDistrict('All');
              }}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="All">All States (India)</option>
              {INDIAN_STATES.map((s) => (
                <option key={s.name} value={s.name}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* District Filter */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">District</label>
            <select
              value={filterDistrict}
              onChange={(e) => setFilterDistrict(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="All">All Districts</option>
              {(filterState === 'All'
                ? []
                : INDIAN_STATES.find(
                    (s) => s.name.toLowerCase() === filterState.toLowerCase() || s.stateName?.toLowerCase() === filterState.toLowerCase()
                  )?.districts || []
              ).map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">Department</label>
            <select
              value={filterDept}
              onChange={(e) => setFilterDept(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="All">All Departments</option>
              {NATIONAL_DEPARTMENTS_CONFIG.map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">Priority</label>
            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="All">All Priorities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-slate-600 font-medium mb-1">Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Routed">Routed / Assigned</option>
              <option value="In Progress">In Progress</option>
              <option value="Resolved">Resolved</option>
              <option value="Pending">Pending</option>
            </select>
          </div>
        </div>
      </div>

      {/* Complaints List Table / Card View */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>Displaying {filteredComplaints.length} Grievance Records</span>
          <span className="text-slate-400 font-normal">Click any card to expand multi-issue work orders</span>
        </div>

        {filteredComplaints.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 text-slate-400">
            <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm font-medium">No complaints match your active filter criteria.</p>
          </div>
        ) : (
          filteredComplaints.map((c) => {
            const isExpanded = expandedComplaintId === c.id;
            return (
              <div
                key={c.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:border-blue-300 transition-all"
              >
                {/* Collapsed Header Bar */}
                <div
                  onClick={() => setExpandedComplaintId(isExpanded ? null : c.id)}
                  className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-slate-50/70 select-none"
                >
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </button>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-blue-700">{c.id}</span>
                        <span
                          className={`px-2 py-0.2 rounded-full text-[10px] font-bold uppercase tracking-wide border ${
                            c.overallPriority === 'Critical'
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : c.overallPriority === 'High'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          {c.overallPriority}
                        </span>
                        <span
                          className={`px-2 py-0.2 rounded-full text-[10px] font-bold border ${
                            c.overallStatus === 'Resolved'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : c.overallStatus === 'In Progress'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {c.overallStatus}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 mt-0.5 line-clamp-1">
                        {c.complaintTitle}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <div className="hidden sm:block text-right">
                      <span className="font-medium text-slate-700 block">
                        {c.location.area}, {c.location.district}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {c.location.state || 'India'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs border border-blue-200">
                      <span>{c.issuesDetected.length} Work Orders</span>
                    </div>
                  </div>
                </div>

                {/* Expanded Multi-Issue Detail View */}
                {isExpanded && (
                  <div className="p-5 bg-slate-50 border-t border-slate-200 space-y-4 animate-fade-in">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="text-slate-600">
                        <strong>Citizen:</strong> {c.citizen.name} ({c.citizen.mobile}) •{' '}
                        <strong>Language:</strong> {c.detectedLanguage || 'English'} •{' '}
                        <strong>Filed:</strong>{' '}
                        {new Date(c.dateFiled).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </div>

                      <button
                        onClick={() => onSelectComplaintForTracking(c.id)}
                        className="text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Open Citizen Tracking View</span>
                      </button>
                    </div>

                    {/* Original Complaint */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 italic">
                      "{c.originalComplaint}"
                    </div>

                    {/* Work Orders Grid with Officer Status Updates */}
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                        Parallel Department Actions (Officer Status Controls):
                      </span>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {c.issuesDetected.map((issue) => (
                          <IssueCard
                            key={issue.id}
                            issue={issue}
                            isOfficer={true}
                            onUpdateStatus={(newStatus) =>
                              onUpdateIssueStatus(c.id, issue.id, newStatus)
                            }
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
