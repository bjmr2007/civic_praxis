import React from 'react';
import { Complaint } from '../types';
import { Download, FileSpreadsheet, FileText, Printer, X, Check } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaints: Complaint[];
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  complaints,
}) => {
  if (!isOpen) return null;

  // Generate CSV data
  const handleExportCSV = () => {
    const headers = [
      'Complaint ID',
      'Citizen Name',
      'Masked Mobile',
      'District',
      'Area',
      'Ward',
      'Department',
      'Issue Summary',
      'Priority',
      'SLA Deadline',
      'Confidence Score',
      'Status',
      'Assigned Officer',
      'Date Filed',
    ];

    const rows: string[][] = [];

    complaints.forEach((c) => {
      c.issuesDetected.forEach((issue) => {
        rows.push([
          `"${c.id}"`,
          `"${c.citizen.name}"`,
          `"${c.citizen.mobile}"`,
          `"${c.location.district}"`,
          `"${c.location.area}"`,
          `"${c.location.ward}"`,
          `"${issue.department}"`,
          `"${issue.issueSummary.replace(/"/g, '""')}"`,
          `"${issue.priority}"`,
          `"${issue.deadline}"`,
          `"${issue.confidenceScore}%"`,
          `"${issue.status}"`,
          `"${issue.assignedOfficer || 'Field Team'}"`,
          `"${c.dateFiled}"`,
        ]);
      });
    });

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Civic_Praxis_Grievance_Export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg p-6 overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Export Grievance & SLA Data
              </h3>
              <p className="text-xs text-slate-500">
                Official CIVIC PRAXIS governance extract for district review
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3.5 my-4">
          {/* CSV card */}
          <div
            onClick={handleExportCSV}
            className="p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700">
                  Export to CSV / Excel
                </h4>
                <p className="text-xs text-slate-500">
                  Includes all {complaints.length} complaints and split sub-issues with SLA metrics
                </p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-xs">
              Download CSV
            </span>
          </div>

          {/* PDF / Print report card */}
          <div
            onClick={handlePrintReport}
            className="p-4 rounded-xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/30 transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                  Print / Save as PDF Summary
                </h4>
                <p className="text-xs text-slate-500">
                  Formatted official Government report suitable for District Collector review
                </p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-lg bg-blue-600 text-white text-xs font-bold shadow-xs">
              Print / PDF
            </span>
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
          <p className="font-semibold text-slate-800">Privacy Guarantee:</p>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Export automatically masks citizen identity (phone numbers formatted as 98401XXXXX, Demo ID masked). Full Aadhaar is never collected or stored.
          </p>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
