import React, { useState } from 'react';
import { Star, X, CheckCircle, Send } from 'lucide-react';
import { Department } from '../types';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaintId: string;
  citizenName: string;
  department: Department;
  onSubmitFeedback: (data: { complaintId: string; citizenName: string; rating: number; comments: string; department: Department }) => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  complaintId,
  citizenName,
  department,
  onSubmitFeedback,
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comments, setComments] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitFeedback({
      complaintId,
      citizenName,
      rating,
      comments: comments || 'Grievance resolved promptly. Modern routing system is very helpful.',
      department,
    });
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">⭐</span>
            <h3 className="text-base font-bold text-slate-900">
              Citizen Satisfaction Feedback
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center animate-in zoom-in-95 duration-200">
            <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto mb-2" />
            <h4 className="text-lg font-bold text-slate-900">Nandri! Thank You</h4>
            <p className="text-xs text-slate-600 mt-1">
              Your feedback helps Tamil Nadu smart governance improve department response times.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="bg-blue-50 p-3 rounded-xl border border-blue-100 text-blue-900">
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block">
                Complaint Reference
              </span>
              <p className="font-mono font-bold">{complaintId}</p>
              <p className="text-[11px] text-blue-700 mt-0.5">Department: {department}</p>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1.5">
                Was your civic problem resolved to your satisfaction?
              </label>
              <div className="flex items-center gap-2 py-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 cursor-pointer transition-transform hover:scale-125 focus:outline-none"
                  >
                    <Star
                      className={`w-7 h-7 ${
                        star <= (hoverRating || rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 font-bold text-slate-700 text-sm">
                  {rating} / 5
                </span>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Tell us about your experience (optional):
              </label>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={3}
                placeholder="Share your thoughts on the officer's resolution speed, work quality, or SMS alerts..."
                className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Feedback</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
