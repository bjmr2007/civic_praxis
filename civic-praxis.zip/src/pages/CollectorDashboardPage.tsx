import React, { useState } from 'react';
import { Complaint, Hotspot, PredictiveRisk, AuthenticatedUser } from '../types';
import { INDIAN_STATES } from '../data/indiaLocations';
import { useLanguage } from '../context/LanguageContext';
import {
  ShieldAlert,
  Building2,
  Flame,
  CheckCircle2,
  Clock,
  MapPin,
  Sparkles,
  Download,
  Eye,
  Filter,
  Search,
} from 'lucide-react';

interface CollectorDashboardPageProps {
  complaints: Complaint[];
  hotspots: Hotspot[];
  predictiveRisks: PredictiveRisk[];
  currentUser?: AuthenticatedUser | null;
  onSelectComplaintForTracking: (complaintId: string) => void;
  onOpenExportModal: () => void;
  onOpenAuthModal?: () => void;
}

export const CollectorDashboardPage: React.FC<CollectorDashboardPageProps> = ({
  complaints,
  hotspots,
  predictiveRisks,
  currentUser,
  onSelectComplaintForTracking,
  onOpenExportModal,
}) => {
  const { t } = useLanguage();
  const [selectedState, setSelectedState] = useState<string>(currentUser?.state || 'Maharashtra');
  const [selectedDistrict, setSelectedDistrict] = useState<string>(currentUser?.district || 'All');
  const [searchQuery, setSearchQuery] = useState('');

  // Find districts for selected state
  const stateObj = INDIAN_STATES.find(
    (s) => s.name.toLowerCase() === selectedState.toLowerCase() || s.stateName?.toLowerCase() === selectedState.toLowerCase()
  );
  const districtList = stateObj ? stateObj.districts : [];

  const handleStateChange = (newState: string) => {
    setSelectedState(newState);
    setSelectedDistrict('All');
  };

  // Filter complaints based on jurisdiction & search query
  const jurisdictionComplaints = complaints.filter((c) => {
    if (selectedState && c.location.state && c.location.state.toLowerCase() !== selectedState.toLowerCase()) {
      return false;
    }
    if (selectedDistrict && selectedDistrict !== 'All' && c.location.district.toLowerCase() !== selectedDistrict.toLowerCase()) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesId = c.id.toLowerCase().includes(q);
      const matchesTitle = c.complaintTitle.toLowerCase().includes(q);
      const matchesCitizen = (c.citizen?.name || '').toLowerCase().includes(q);
      const matchesArea = (c.location.area || '').toLowerCase().includes(q);
      const matchesDept = c.issuesDetected.some((i) => i.department.toLowerCase().includes(q));
      if (!matchesId && !matchesTitle && !matchesCitizen && !matchesArea && !matchesDept) {
        return false;
      }
    }
    return true;
  });

  // Calculate executive statistics
  const totalGrievances = jurisdictionComplaints.length;
  const criticalCount = jurisdictionComplaints.filter((c) => c.overallPriority === 'Critical').length;
  const multiDeptGrievances = jurisdictionComplaints.filter((c) => c.issuesDetected.length > 1);
  const resolvedCount = jurisdictionComplaints.filter((c) => c.overallStatus === 'Resolved').length;

  return (
    <div className="max-w-7xl mx-auto py-4 space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-indigo-100 text-indigo-700">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {t.collectorPortalTitle}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {t.collectorPortalDesc}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* State Jurisdiction Dropdown */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs shadow-2xs">
            <span className="text-[11px] font-bold text-slate-400">State:</span>
            <select
              value={selectedState}
              onChange={(e) => handleStateChange(e.target.value)}
              aria-label="Select State"
              className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer max-w-[150px] truncate"
            >
              {INDIAN_STATES.map((s) => (
                <option key={s.name} value={s.name}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* District Jurisdiction Dropdown - All Districts Option Available */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs shadow-2xs">
            <span className="text-[11px] font-bold text-slate-400">District:</span>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              aria-label="Select District"
              className="bg-transparent font-bold text-blue-700 focus:outline-none cursor-pointer max-w-[170px] truncate"
            >
              <option value="All">All Districts ({selectedState})</option>
              {districtList.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export District Summary</span>
          </button>
        </div>
      </div>

      {/* Collector Executive Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>District Active Docket</span>
            <Building2 className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-3xl font-black text-slate-900">{totalGrievances}</p>
          <span className="text-[11px] text-slate-400">
            {selectedDistrict === 'All' ? `All ${selectedState} Districts` : `${selectedDistrict} Jurisdiction`}
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Multi-Department Work Orders</span>
            <Sparkles className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-3xl font-black text-indigo-600">{multiDeptGrievances.length}</p>
          <span className="text-[11px] text-indigo-500">Requires joint agency coordination</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Emergency / Critical</span>
            <Flame className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-3xl font-black text-rose-600">{criticalCount}</p>
          <span className="text-[11px] text-rose-500">&lt; 24h statutory resolution threshold</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Redressal Rate</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-3xl font-black text-emerald-600">
            {totalGrievances > 0 ? Math.round((resolvedCount / totalGrievances) * 100) : 100}%
          </p>
          <span className="text-[11px] text-emerald-500">Citizen Charter delivery benchmark</span>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex items-center gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        <Search className="w-4 h-4 text-slate-400 ml-2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={`Search petitions in ${selectedDistrict === 'All' ? selectedState : selectedDistrict} by ID, citizen, area, or department...`}
          className="w-full text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="text-xs text-slate-400 hover:text-slate-600 px-2 py-0.5 rounded font-semibold"
          >
            Clear
          </button>
        )}
      </div>

      {/* Multi-Department Joint Coordination Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-black text-slate-900">
              Joint Inter-Agency Work Orders in {selectedDistrict === 'All' ? selectedState : selectedDistrict}
            </h3>
            <p className="text-xs text-slate-500">
              Grievances split across 2 or more government bodies requiring joint Collectorate taskforce action.
            </p>
          </div>
          <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold border border-indigo-200">
            {multiDeptGrievances.length} Active Joint Operations
          </span>
        </div>

        {multiDeptGrievances.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-700">No Pending Joint Work Orders</p>
            <p className="text-[11px] text-slate-500 mt-1">
              All multi-department operations in {selectedDistrict === 'All' ? selectedState : selectedDistrict} are up to date.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {multiDeptGrievances.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 transition-all bg-slate-50/50 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-blue-700">{c.id}</span>
                    <span className="text-xs font-bold text-slate-900">{c.complaintTitle}</span>
                  </div>
                  <div className="text-xs text-slate-500">
                    <MapPin className="w-3.5 h-3.5 inline mr-1 text-slate-400" />
                    <span>{c.location.area}, {c.location.district}</span>
                  </div>
                </div>

                {/* Departments involved badge list */}
                <div className="flex flex-wrap gap-1.5 items-center">
                  <span className="text-[11px] font-bold text-slate-500 mr-1">Coordinated Departments:</span>
                  {c.issuesDetected.map((issue) => (
                    <span
                      key={issue.id}
                      className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-xs font-semibold text-slate-800 flex items-center gap-1 shadow-2xs"
                    >
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span>{issue.department}</span>
                      <span className="text-[10px] text-slate-400">({issue.deadline})</span>
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                  <span className="text-slate-500 italic line-clamp-1 max-w-xl">
                    "{c.originalComplaint}"
                  </span>
                  <button
                    onClick={() => onSelectComplaintForTracking(c.id)}
                    className="text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Inspect Docket</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Proactive Risk & Deluge Forecast for District */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-rose-500" />
              <h3 className="text-base font-black text-slate-900">
                Collectorate Hotspot Watchlist
              </h3>
            </div>
            <span className="text-xs font-bold text-slate-400">{hotspots.length} Clusters</span>
          </div>

          <div className="space-y-2.5">
            {hotspots.map((h) => (
              <div
                key={h.id}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white transition-colors flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <strong className="text-slate-800 block">{h.locationName}</strong>
                  <span className="text-slate-500 text-[11px]">{h.issueType} • {h.department}</span>
                </div>
                <div className="text-right shrink-0">
                  <span className="px-2 py-0.5 rounded font-mono font-bold bg-rose-100 text-rose-700">
                    {h.complaintCount} Petitions
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h3 className="text-base font-black text-slate-900">
                Predictive Governance Foresight
              </h3>
            </div>
            <span className="text-xs font-bold text-emerald-600">AI Foresight Radar</span>
          </div>

          <div className="space-y-3">
            {predictiveRisks.map((p) => (
              <div
                key={p.id}
                className="p-3.5 rounded-2xl border border-amber-200 bg-amber-50/50 space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="text-amber-900">{p.title}</span>
                  <span className="px-2 py-0.2 rounded bg-amber-200 text-amber-900 text-[10px] font-mono">
                    {p.timeline || p.timeframe}
                  </span>
                </div>
                <p className="text-slate-700">{p.description || p.aiPrediction}</p>
                <div className="pt-1 text-[11px] text-emerald-800 font-medium">
                  <strong>Recommended Proactive Action:</strong> {p.recommendedPreventiveAction || p.recommendedProactiveAction}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
